SENTINEL v2.4.0 — COMPLETE BUNDLE
=================================
sentinel-2.4.0-source.zip   self-sufficient source (12 modules + browser/DOM engine,
                            auth engine, OAST local+public providers, fixtures v5,
                            49-test suite, ground truth v5, CHANGELOG)
sentinel-results/           every real-target scan (v2.0.0 -> v2.4.0), full benchmark
                            evolution, repair campaigns, reports, sentinel.db,
                            strategy store, ground truth, WORKLOG
Quick start: unzip source -> python -m sentinel.cli doctor
             python -m sentinel.cli benchmark
             python -m sentinel.cli scan https://<authorized-target> --oast public
