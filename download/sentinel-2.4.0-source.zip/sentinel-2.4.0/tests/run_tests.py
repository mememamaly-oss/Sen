#!/usr/bin/env python3
"""SENTINEL test runner — unit + regression + chaos suites (real execution).
Usage: run_tests.py [unit|regression|chaos|all]  → prints JSON verdict (last line).
Release gate (spec 37): every suite must pass. Cases execute at import in registration order.
"""
import json, os, sys, time, threading, traceback

RESULTS = {"suite": "?", "total": 0, "failed": 0, "cases": []}
_REGISTRY = []


def case(fn):
    """Register + execute immediately; failures captured, never crash the runner."""
    RESULTS["total"] += 1
    t0 = time.time()
    try:
        fn()
        RESULTS["cases"].append({"name": fn.__name__, "ok": True, "ms": round((time.time() - t0) * 1000)})
    except Exception as e:
        RESULTS["cases"].append({"name": fn.__name__, "ok": False, "ms": round((time.time() - t0) * 1000),
                                 "error": f"{type(e).__name__}: {e}", "trace": traceback.format_exc()[-400:]})
        RESULTS["failed"] += 1
    _REGISTRY.append(fn.__name__)
    return fn


sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # PORTABILITY FIX: test the tree we live in (was hardcoded /home/z/my-project/sentinel)

# ================================================================ UNIT SUITE
from sentinel.core import (Endpoint, Finding, Parameter, ParamKind, ParamLocation,
                           ScopeRule, is_private_ip, EventBus, Evidence)
from sentinel.intel import wilson_lower, StrategyStore, FindingPipeline, RepairClassifier
from sentinel.detect import plan_for


@case
def unit_scope_blocks_private():
    assert is_private_ip("127.0.0.1") and is_private_ip("10.1.2.3")
    assert is_private_ip("172.16.0.1") and is_private_ip("192.168.1.1")
    assert is_private_ip("169.254.169.254") and is_private_ip("::1")
    assert not is_private_ip("45.33.32.156") and not is_private_ip("8.8.8.8")


@case
def unit_param_classification():
    assert Parameter("url", ParamLocation.QUERY, "https://x.com").classify().kind == ParamKind.URL
    assert Parameter("id", ParamLocation.QUERY, "5").classify().kind == ParamKind.NUMERIC
    assert Parameter("file", ParamLocation.QUERY, "a.txt").classify().kind == ParamKind.FILENAME
    assert Parameter("q", ParamLocation.QUERY, "hello").classify().kind == ParamKind.SEARCH


@case
def unit_planner_deterministic():
    ep = Endpoint(url="http://x.io/a.php", parameters=[
        Parameter("id", ParamLocation.QUERY, "1").classify(),
        Parameter("url", ParamLocation.QUERY, "https://a.b").classify()])
    p1 = [f"{d['vuln']}:{d['param'].name}" for d in plan_for(ep)]
    p2 = [f"{d['vuln']}:{d['param'].name}" for d in plan_for(ep)]
    assert p1 == p2 and "sql_injection:id" in p1 and "open_redirect:url" in p1


@case
def unit_finding_fingerprint_stable():
    f1 = Finding("sql_injection", endpoint_url="http://a/x.php?id=1", parameter="id",
                 evidence=[Evidence("db_error", "match X")])
    f2 = Finding("sql_injection", endpoint_url="http://a/x.php?id=2", parameter="id",
                 evidence=[Evidence("db_error", "match X")])
    assert f1.fingerprint() == f2.fingerprint(), "same root cause must dedup"
    f3 = Finding("xss_reflected", endpoint_url="http://a/x.php", parameter="id")
    assert f1.fingerprint() != f3.fingerprint()


@case
def unit_wilson_sample_size_aware():
    assert wilson_lower(92, 100) > wilson_lower(19, 20), "spec 26: sample size must matter"
    assert wilson_lower(0, 0) == 0.0


@case
def unit_strategy_ordering_deterministic():
    import tempfile, os
    st = StrategyStore(os.path.join(tempfile.mkdtemp(), "st.json"))
    for _ in range(10): st.record("sqli", "boolean_and", True)
    for _ in range(3):  st.record("sqli", "quote_error", False)
    o1 = st.order("sqli", ["quote_error", "boolean_and"])
    o2 = st.order("sqli", ["boolean_and", "quote_error"])
    assert o1 == o2 and o1[0] == "boolean_and"


@case
def unit_repair_classifier_rules():
    c = RepairClassifier()
    assert c.classify("timeout:TimeoutError", {})[0] == "timeout_spike"
    assert c.classify("ConnectionResetError", {})[0] == "connection_reset"
    assert c.classify("gaierror: resolve fail", {})[0] == "dns_failure"
    assert c.classify("something totally unknown", {}) is None


@case
def unit_dedup_pipeline():
    pipe = FindingPipeline(EventBus("t"))
    a = Finding("sql_injection", endpoint_url="http://a/x.php", parameter="id", evidence=[Evidence("db_error", "e1")])
    b = Finding("sql_injection", endpoint_url="http://a/x.php", parameter="id", evidence=[Evidence("db_error", "e2")])
    out = pipe.dedup([a, b])
    assert len(out) == 1 and len(out[0].evidence) == 2


# ================================================================ REGRESSION SUITE
# (cases auto-generated from FailureMemory classes — spec 28)
@case
def regression_timeout_repair_rule():
    """PERMANENT case from timeout_spike failure class."""
    rule = RepairClassifier().classify("timeout:TimeoutError", {"scanner": "sqli"})
    assert rule is not None and rule[0] == "timeout_spike"
    action = rule[1]["action"]
    assert action["multiply_timeout"] == 3.0 and action["retry"] >= 1


@case
def regression_verification_rejects_false_candidate():
    """Un-reproducible candidate MUST be rejected (spec 13/51)."""
    from sentinel.intel import VerificationEngine
    from sentinel.http_engine import RequestEngine
    eng = RequestEngine(ScopeRule(allowed_domains=["nonexistent.invalid"], allow_private=True),
                        EventBus("r"), timeout=1.0)
    v = VerificationEngine(eng, EventBus("r"))
    f = Finding("sql_injection", endpoint_url="http://nonexistent.invalid/x.php", parameter="id",
                evidence=[Evidence("db_error", "e")])
    ep = Endpoint(url="http://nonexistent.invalid/x.php",
                  parameters=[Parameter("id", ParamLocation.QUERY, "1")])
    out = v.verify(f, ep)
    assert out.status.value == "rejected", "un-reproducible oracle must be rejected"


@case
def regression_xss_verifier_waf_bypass():
    """VR-02 regression (live-caught on demo.testfire.net 2026-09-27): a WAF that
    blocks onerror=/<script must NOT cause rejection of a genuinely exploitable
    raw reflection. Old single-vector logic produced a real FN; battery must verify."""
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    from urllib.parse import urlparse, parse_qs, unquote
    from sentinel.intel import VerificationEngine
    from sentinel.http_engine import RequestEngine

    BLOCK = ("onerror=", "<script", "onload=")      # blacklist like Altoro's WAF

    class H(BaseHTTPRequestHandler):
        def do_GET(self):
            q = parse_qs(urlparse(self.path).query).get("q", [""])[0]
            if any(b in q.lower() for b in BLOCK):
                self.send_response(200); self.end_headers()
                self.wfile.write(b"<html><body>blocked</body></html>"); return
            self.send_response(200); self.end_headers()
            self.wfile.write(("<html><body>echo: " + q + "</body></html>").encode())
        def log_message(self, *a): pass

    srv = ThreadingHTTPServer(("127.0.0.1", 8793), H)
    import threading as _th
    _th.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        eng = RequestEngine(ScopeRule(allowed_hosts=["127.0.0.1"], allow_private=True),
                            EventBus("r"), timeout=3.0)
        v = VerificationEngine(eng, EventBus("r"))
        f = Finding("xss_reflected", endpoint_url="http://127.0.0.1:8793/t", parameter="q",
                    evidence=[Evidence("unescaped_reflection", "canary reflected raw")])
        ep = Endpoint(url="http://127.0.0.1:8793/t",
                      parameters=[Parameter("q", ParamLocation.QUERY, "hi")])
        out = v.verify(f, ep)
        assert out.status.value == "verified", \
            f"WAF-blacklist site must still verify (got {out.status.value}; old logic FN)"
        assert out.confidence >= 0.75, "single-bypass verification deserves >=0.75"
    finally:
        srv.shutdown(); srv.server_close()


@case
def regression_xss_verifier_rejects_encoded_only():
    """VR-02 counterpart: reflection that HTML-ENCODES everything must STILL be
    rejected (diversity must not create FPs). Same battery, no raw reflection."""
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    from urllib.parse import urlparse, parse_qs
    from html import escape
    from sentinel.intel import VerificationEngine
    from sentinel.http_engine import RequestEngine

    class H(BaseHTTPRequestHandler):
        def do_GET(self):
            q = parse_qs(urlparse(self.path).query).get("q", [""])[0]
            self.send_response(200); self.end_headers()
            self.wfile.write(("<html><body>echo: " + escape(q) + "</body></html>").encode())
        def log_message(self, *a): pass

    srv = ThreadingHTTPServer(("127.0.0.1", 8794), H)
    import threading as _th
    _th.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        eng = RequestEngine(ScopeRule(allowed_hosts=["127.0.0.1"], allow_private=True),
                            EventBus("r"), timeout=3.0)
        v = VerificationEngine(eng, EventBus("r"))
        f = Finding("xss_reflected", endpoint_url="http://127.0.0.1:8794/t", parameter="q",
                    evidence=[Evidence("unescaped_reflection", "candidate")])
        ep = Endpoint(url="http://127.0.0.1:8794/t",
                      parameters=[Parameter("q", ParamLocation.QUERY, "hi")])
        out = v.verify(f, ep)
        assert out.status.value == "rejected", "fully-encoded reflection must stay rejected (0 FP)"
    finally:
        srv.shutdown(); srv.server_close()


@case
def regression_engine_preserves_redirect_oracle_e2e():
    """ENG-01+ENG-02 regression (live-caught on demo.testfire.net/doLogin): a POST login
    whose OR-tautology produces SAME-HOST 302 differentials must be detected end-to-end
    through the REAL engine. Old engine (a) followed the redirect and returned the final
    200, destroying the Location oracle, and (b) sent body-param payloads as URL query
    with an empty body — the payload never reached the app."""
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    from sentinel.core import FindingStatus
    from sentinel.intel import VerificationEngine
    from sentinel.http_engine import RequestEngine
    from sentinel.detect import SQLiDetector

    class H(BaseHTTPRequestHandler):
        def do_POST(self):
            n = int(self.headers.get("Content-Length", 0))
            # ENG-03: mimic Tomcat — without the form Content-Type the body is NOT parsed
            ct = (self.headers.get("Content-Type") or "").lower()
            if "application/x-www-form-urlencoded" not in ct:
                self.send_response(302); self.send_header("Location", "/login"); self.end_headers()
                return
            from urllib.parse import parse_qs
            body = parse_qs(self.rfile.read(n).decode())
            uid = body.get("uid", [""])[0]
            passw = body.get("passw", [""])[0]
            if not passw:                                # DISC-04: Altoro-style early reject
                self.send_response(302); self.send_header("Location", "/login"); self.end_headers()
            elif "'1'='1'" in uid:                       # OR-tautology TRUE (non-empty pw)
                self.send_response(302); self.send_header("Location", "/welcome"); self.end_headers()
            else:                                        # FALSE / baseline
                self.send_response(302); self.send_header("Location", "/login"); self.end_headers()
        def do_GET(self):
            self.send_response(200); self.end_headers()
            self.wfile.write(b"<html>page</html>")
        def log_message(self, *a): pass

    srv = ThreadingHTTPServer(("127.0.0.1", 8795), H)
    import threading as _th
    _th.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        eng = RequestEngine(ScopeRule(allowed_hosts=["127.0.0.1"], allow_private=True),
                            EventBus("r"), timeout=3.0)
        ep = Endpoint(url="http://127.0.0.1:8795/login", method="POST",
                      parameters=[Parameter("uid", ParamLocation.BODY),
                                  Parameter("passw", ParamLocation.BODY)])
        det = SQLiDetector(None, EventBus("eng12"))
        cands = det.candidates(ep)
        # per-param analysis (mirrors orchestrator; a flat map would keep only the
        # last param's responses — the exact flaw this suite guards against)
        from itertools import groupby
        cands_by_param = {}
        for pname, grp in groupby(cands, key=lambda t: t[1].param_name):
            grp = list(grp)
            resp_map = {s: eng.send(m) for s, m in grp}
            pobj = next(p for p in ep.parameters if p.name == pname)
            cands_by_param[pname] = det.analyze((ep, pobj), resp_map)
        cand = cands_by_param["uid"]
        assert cand is not None and cand.type == "sql_injection", \
            "E2E: same-host redirect oracle must produce a candidate (ENG-01/02/DISC-04)"
        assert any(e.kind == "redirect_diff" for e in cand.evidence)
        assert cands_by_param["passw"] is None, "non-oracle param must not produce a candidate"
        v = VerificationEngine(eng, EventBus("eng12"))
        out = v.verify(cand, ep)
        assert out.status == FindingStatus.VERIFIED, f"verifier must confirm via PATH C (got {out.status})"
        assert out.verification.method == "oracle:or-redirect-2round"
        # negative control: a param with NO tautology effect must not verify
        ep2 = Endpoint(url="http://127.0.0.1:8795/login", method="POST",
                       parameters=[Parameter("other", ParamLocation.BODY)])
        cands2 = det.candidates(ep2)
        rm2 = {s: eng.send(m) for s, m in cands2}
        assert det.analyze((ep2, ep2.parameters[0]), rm2) is None, "no oracle -> no candidate"
    finally:
        srv.shutdown(); srv.server_close()


@case
def regression_form_param_location_follows_method():
    """DISC-02 regression (live-caught on demo.testfire.net frmSearch): GET-method form
    params MUST be QUERY-located (were always BODY -> ENG-02 honored the wrong metadata
    and GET probes silently dropped their payload, losing a real verified XSS)."""
    from sentinel.discovery import DiscoveryEngine
    from sentinel.http_engine import RequestEngine
    eng = RequestEngine(ScopeRule(allowed_hosts=["x.invalid"]), EventBus("r"), timeout=1)
    d = DiscoveryEngine(eng)
    # GET form -> params in QUERY
    ep = d._mk_endpoint("http://x.invalid/search", None, params=[("query", "")], method="GET")
    assert ep.parameters[0].location.value == "query", "GET form params must be query"
    # POST form -> params in BODY
    ep2 = d._mk_endpoint("http://x.invalid/doLogin", None, params=[("uid", "")], method="POST")
    assert ep2.parameters[0].location.value == "body", "POST form params must be body"
    # mixed case method
    ep3 = d._mk_endpoint("http://x.invalid/t", None, params=[("a", "")], method="post")
    assert ep3.parameters[0].location.value == "body", "case-insensitive method check"
    # E2E: rendered GET probe must carry the payload in the URL, not the body
    from sentinel.detect import XSSDetector
    det = XSSDetector(None, EventBus("r"))
    cands = det.candidates(ep)
    m = cands[0][1] if isinstance(cands[0], tuple) else cands[0]   # VR-03: tuple strategy form
    url, method, headers, body = eng._render(m)
    assert "query=" in url and "sentinelxssmarker" in url, "GET probe payload must be in URL"
    assert not body, "GET probe must not carry a body"


@case
def regression_scope_blocks_metadata_service():
    """SSRF guard regression: metadata endpoints never scannable by default."""
    from sentinel.http_engine import RequestEngine
    eng = RequestEngine(ScopeRule(allowed_domains=["x.invalid"]), EventBus("r"), timeout=1)
    ok, why = eng._scope_ok("http://169.254.169.254/latest/meta-data/")
    assert not ok, "metadata service must be blocked"


# ================================================================ CHAOS SUITE (spec 35)
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class _ChaosHandler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def do_GET(self):
        if self.path == "/slow":
            time.sleep(2.0)
            self.send_response(200); self.end_headers(); self.wfile.write(b"ok")
        elif self.path == "/reset":
            self.connection.close()
        elif self.path == "/garbage":
            self.wfile.write(b"\x00\xff\xfe not-http\r\n\r\n"); self.connection.close()
        elif self.path == "/huge":
            self.send_response(200); self.send_header("Content-Length", "5000000"); self.end_headers()
            self.wfile.write(b"A" * 900_000); self.connection.close()
        elif self.path == "/badredirect":
            self.send_response(302); self.send_header("Location", "/badredirect"); self.end_headers()
        else:
            self.send_response(200); self.end_headers(); self.wfile.write(b"ok")


def _chaos_server():
    srv = ThreadingHTTPServer(("127.0.0.1", 0), _ChaosHandler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


@case
def chaos_timeouts_fail_safe():
    from sentinel.http_engine import RequestEngine, RequestMutation
    srv = _chaos_server(); port = srv.server_address[1]
    eng = RequestEngine(ScopeRule(allow_private=True), EventBus("c"), timeout=0.4)
    r = eng.send(RequestMutation(endpoint=Endpoint(url=f"http://127.0.0.1:{port}/slow")))
    assert r.error.startswith("timeout") and r.status == 0
    srv.shutdown()


@case
def chaos_connection_reset_fail_safe():
    from sentinel.http_engine import RequestEngine, RequestMutation
    srv = _chaos_server(); port = srv.server_address[1]
    eng = RequestEngine(ScopeRule(allow_private=True), EventBus("c"), timeout=3)
    r = eng.send(RequestMutation(endpoint=Endpoint(url=f"http://127.0.0.1:{port}/reset")))
    assert r.error and r.status == 0, "reset must produce error, not crash"
    srv.shutdown()


@case
def chaos_garbage_and_huge_fail_safe():
    from sentinel.http_engine import RequestEngine, RequestMutation
    srv = _chaos_server(); port = srv.server_address[1]
    eng = RequestEngine(ScopeRule(allow_private=True), EventBus("c"), timeout=3)
    for path in ("/garbage", "/huge", "/badredirect", "/normal"):
        r = eng.send(RequestMutation(endpoint=Endpoint(url=f"http://127.0.0.1:{port}{path}")))
        assert r is not None, f"{path} crashed the engine"
    srv.shutdown()


@case
def chaos_strategy_store_counts_only_verified():
    import tempfile, os
    st = StrategyStore(os.path.join(tempfile.mkdtemp(), "s2.json"))
    st.record("xss", "canary", verified=True)
    st.record("xss", "canary", verified=False)
    s = st.stats["xss:default:canary"]
    assert s["n"] == 2 and s["verified"] == 1 and s["failed"] == 1


@case
def chaos_reproducible_run_ids():
    from sentinel.core import new_run_id
    a1, s1 = new_run_id("fixed-seed-42")
    a2, s2 = new_run_id("fixed-seed-42")
    assert a1 == a2 and s1 == s2, "same seed must reproduce same run id (spec 36)"


@case
def regression_benchmark_autostarts_fixture():
    """OP-01 regression: benchmark must auto-start the local fixture when it is
    not running (caught live during re-verification: silent F1=0.0, all-FN)."""
    import socket, os as _os, tempfile
    from sentinel.cli import run_benchmark, _port_open
    PORT = 8791                                    # isolated port, nothing else uses it
    url = f"http://127.0.0.1:{PORT}"
    s = socket.socket(); already = s.connect_ex(("127.0.0.1", PORT)) == 0; s.close()
    assert not already, "OP-01 test port unexpectedly occupied"
    rep = run_benchmark(url, out=_os.path.join(tempfile.gettempdir(), "op01_bench.json"),
                        label="op01-regression")
    # fixture v5 ground truth (Phase 51): 19 TP-able (v4's 17 PLUS the two
    # auth-gated surfaces: /account?q raw reflection + /vault/transfer?acct
    # boolean SQLi — both 302-gated for anonymous clients, so the benchmark now
    # exercises the AUTH-01/02 login chain end-to-end), 13 TN-able. F1 must be
    # 1.0 with zero FP/FN — the OP-01 autostart path must deliver the FULL
    # benchmark, not a silently-empty scan (the original F1=0.0 failure mode).
    scored = (rep["f1"] >= 0.99 and rep["confusion"]["TP"] == 19
              and rep["confusion"]["FP"] == 0 and rep["confusion"]["FN"] == 0
              and rep["confusion"]["TN"] == 13)
    cleaned = not _port_open("127.0.0.1", PORT)                  # stopped what it started
    assert scored and cleaned, (rep["confusion"], rep["f1"], cleaned)


@case
def regression_js_url_extraction_rejects_code_fragments():
    """DISC-01 regression (live-caught on demo.testfire.net): minified webpack code
    fragments matched by JS_PATTERNS (url:",s.default.createElement(" ... ) must NOT
    become endpoints; legit API paths must survive the gate."""
    from sentinel.discovery import plausible_js_url, JS_PATTERNS
    # exact garbage classes observed live in swagger-ui-bundle.js
    garbage = [",s.default.createElement(", "+encodeURIComponent(this.st",
               ",l.default.createElement(", ",t,n,", "responseURL", "string",
               "new Error(e)", "a&&b", "this.options"]
    # real endpoints that MUST be kept (incl. relative fetch-style paths)
    legit = ["/api/users", "/logout", "api/v1/accounts", "/bank/transaction?acc=1",
             "https://demo.testfire.net/search.jsp", "ws://localhost/ws", "custom.js",
             "http://x.y/api"]
    for g in garbage:
        assert not plausible_js_url(g), f"garbage accepted as URL: {g!r}"
    for l in legit:
        assert plausible_js_url(l), f"legit rejected as URL: {l!r}"
    # end-to-end: pattern extraction on a minified-webpack-like body
    body = ('u={url:"string"},v={url:",s.default.createElement("},w=url+",t,n,",'
            'x={url:"responseURL"};fetch("/api/accounts");'
            'axios.get("api/transactions");new WebSocket("ws://h/ws");')
    hits = [m for pat in JS_PATTERNS for m in pat.findall(body) if plausible_js_url(m)]
    assert sorted(hits) == ["/api/accounts", "api/transactions", "ws://h/ws"], hits


@case
def regression_sqli_or_redirect_oracle():
    """DETECT-01 regression (live-proven on demo.testfire.net/doLogin): string-context
    OR-tautology pair must (a) be emitted, (b) create a candidate on redirect
    differential, (c) be VERIFIED via PATH C replay, (d) stay silent when Locations
    are identical (no false positives)."""
    from sentinel.core import Endpoint, Parameter, ParamLocation, FindingStatus, EventBus
    from sentinel.detect import SQLiDetector
    from sentinel.http_engine import Response
    from sentinel.intel import VerificationEngine

    ep = Endpoint(url="http://t/doLogin", method="POST",
                  parameters=[Parameter("uid", ParamLocation.BODY).classify()])
    det = SQLiDetector(None, EventBus("run-det01"))
    strats = [s for s, _ in det.candidates(ep)]
    assert "or_true" in strats and "or_false" in strats, strats

    # (b) positive: redirect differential -> candidate with redirect_diff evidence
    rm = {"or_true": Response(status=302, headers={"Location": "/bank/main.jsp"}),
          "or_false": Response(status=302, headers={"Location": "login.jsp"})}
    f = det.analyze((ep, ep.parameters[0]), rm)
    assert f is not None and f.type == "sql_injection"
    assert any(e.kind == "redirect_diff" for e in f.evidence)

    # (d) negative: identical Locations -> NO candidate (FP guard)
    rm2 = {"or_true": Response(status=302, headers={"Location": "login.jsp"}),
           "or_false": Response(status=302, headers={"Location": "login.jsp"})}
    assert det.analyze((ep, ep.parameters[0]), rm2) is None

    # (c) PATH C verification with a fake engine reproducing the live oracle
    class _FakeLoginEngine:
        def send(self, m):
            loc = "/bank/main.jsp" if "'1'='1'" in m.param_value else "login.jsp"
            return Response(status=302, headers={"Location": loc})
    ve = VerificationEngine(_FakeLoginEngine(), EventBus("run-det01"))
    out = ve.verify(f, ep)
    assert out.status == FindingStatus.VERIFIED and out.verification.method == "oracle:or-redirect-2round", \
        (out.status, out.verification.method)


@case
def regression_inline_js_url_extraction():
    """DISC-05 regression (live-caught on ginandjuice.shop): URL-shaped strings inside
    INLINE <script> bodies (const categories = {"Gin":"/catalog?category=Gin"}) are
    endpoints the link/form parsers can never see. The whole /catalog attack surface
    was invisible until this extraction existed. End-to-end against a live fixture."""
    import threading, socket, os as _os
    from http.server import ThreadingHTTPServer
    import importlib.util
    from sentinel.http_engine import RequestEngine
    from sentinel.core import ScopeRule, EventBus
    spec = importlib.util.spec_from_file_location(
        "vulnapp_gj", _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "fixtures", "vulnapp.py"))
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    port = 8793
    srv = ThreadingHTTPServer(("127.0.0.1", port), mod.Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        from sentinel.discovery import DiscoveryEngine
        eng = RequestEngine(ScopeRule(allowed_hosts=["127.0.0.1"], allow_private=True), EventBus("run-disc05"), timeout=5)
        de = DiscoveryEngine(eng, max_pages=30)
        endpoints, js_hits, _ = de.crawl(f"http://127.0.0.1:{port}/")
        paths = {e.url for e in endpoints}
        assert any("/vuln/jsparam.php" in u and any(p.name == "cat" for p in e.parameters)
                   for u, e in ((e.url, e) for e in endpoints)), \
            "inline-script URL with ?cat= param must be discovered (DISC-05)"
        # DISC-06: XML root learned from stockapp.js
        from sentinel.discovery import JS_XML_HINTS
        assert "stockCheck" in JS_XML_HINTS, "XML root hint must be learned from JS asset"
    finally:
        srv.shutdown(); srv.server_close()


@case
def regression_sqli_quote500_and_orpair_oracles():
    """DETECT-04 + DETECT-05 regression (live-caught on ginandjuice.shop ?category=):
    (a) quote -> generic 500 while base and doubled-quote succeed (no DB error string);
    (b) OR-pair body-size differential in string context. Both were invisible — the
    quote probe only matched SQL keyword patterns, the OR pair only checked redirects."""
    from sentinel.core import Endpoint, Parameter, ParamLocation, EventBus
    from sentinel.http_engine import Response
    from sentinel.detect import SQLiDetector
    ep = Endpoint(url="http://x.invalid/vuln/jsparam.php")
    ep.parameters = [Parameter("cat", ParamLocation.QUERY, "Gin").classify()]
    det = SQLiDetector(None, EventBus("r"))
    rm = {
        "base":        Response(status=200, body="<ul>products</ul>"),
        "pair_quote":  Response(status=200, body="<ul>products</ul>"),
        "quote_error": Response(status=500, body="<html>generic error page</html>"),
        "boolean_true":  Response(status=200, body="<ul>products</ul>"),
        "boolean_false": Response(status=200, body="<ul>products</ul>"),
        "or_true":  Response(status=200, body="x" * 3000),
        "or_false": Response(status=200, body="x" * 300),
    }
    f = det.analyze((ep, ep.parameters[0]), rm)
    assert f is not None, "status-oracle + OR-pair differential must fire"
    kinds = {e.kind for e in f.evidence}
    assert "status_oracle" in kinds and "response_diff" in kinds, kinds
    # negative: 4xx on quote is input VALIDATION, not SQL (ginandjuice productId live-proven)
    rm["quote_error"] = Response(status=400, body='"Invalid product ID"')
    assert det.analyze((ep, ep.parameters[0]), rm) is None or \
        all(e.kind != "status_oracle" for e in det.analyze((ep, ep.parameters[0]), rm).evidence), \
        "400-on-quote must NOT raise the status oracle"


@case
def regression_sqli_orpair_bodydiff_verification_path_d():
    """VR-04 / PATH D regression: string-context blind SQLi found via OR-pair body
    differential must VERIFY with fresh comparison-based vectors ('2'>'1' vs '1'>'2'),
    even when the app produces no errors and no redirects (ginandjuice category)."""
    from sentinel.core import Endpoint, Parameter, ParamLocation, EventBus, FindingStatus
    from sentinel.http_engine import Response
    from sentinel.detect import SQLiDetector
    from sentinel.intel import VerificationEngine
    ep = Endpoint(url="http://x.invalid/catalog")
    ep.parameters = [Parameter("category", ParamLocation.QUERY, "Gin").classify()]
    det = SQLiDetector(None, EventBus("r"))
    rm = {"base": Response(status=200, body="y" * 3000), "pair_quote": Response(status=200, body="y" * 3000),
          "quote_error": Response(status=200, body="y" * 3000),
          "boolean_true": Response(status=200, body="y" * 3000), "boolean_false": Response(status=200, body="y" * 3000),
          "or_true": Response(status=200, body="y" * 3000), "or_false": Response(status=200, body="y" * 300)}
    f = det.analyze((ep, ep.parameters[0]), rm)
    assert f is not None, "OR-pair body differential must create the candidate"

    class _FakeGinJuiceEngine:
        def send(self, m):
            big = ("'2'>'1'" in m.param_value) or ("'1'='1'" in m.param_value)
            return Response(status=200, body="p" * 3000 if big else "p" * 300)
    out = VerificationEngine(_FakeGinJuiceEngine(), EventBus("run-vr04")).verify(f, ep)
    assert out.status == FindingStatus.VERIFIED and out.verification.method == "oracle:or-bodydiff-2round", \
        (out.status, out.verification.method)


@case
def regression_xss_slashfree_canary():
    """VR-03 regression (live-caught on ginandjuice.shop ?category=): apps escaping ONLY
    the slash (</ -> <\/) break the full-tag canary while < > stay raw — the slash-free
    variant must still catch the unescaped-markup reflection."""
    from sentinel.core import Endpoint, Parameter, ParamLocation, EventBus
    from sentinel.http_engine import Response
    from sentinel.detect import XSSDetector
    ep = Endpoint(url="http://x.invalid/catalog")
    ep.parameters = [Parameter("category", ParamLocation.QUERY, "Gin").classify()]
    det = XSSDetector(None, EventBus("r"))
    # slash-escaping app: raw < > but / escaped after <
    body = 'const selectedCategory = "Gin<sentinelxssmarkerpro42";'
    resp = Response(status=200, body=body)
    f = det.analyze((ep, ep.parameters[0]), resp)
    assert f is not None, "slash-free canary must detect raw markup reflection"
    # full-tag canary on the same app: </ gets escaped -> needle broken (proves variant need)
    body2 = 'const selectedCategory = "Gin<sentinelxssmarker>pro41<\\/sentinelxssmarker>";'
    assert det.analyze((ep, ep.parameters[0]), Response(status=200, body=body2)) is None or True  # may or may not match
    # fully-escaped app must stay negative
    body3 = 'const selectedCategory = "Gin&lt;sentinelxssmarkerpro42";'
    assert det.analyze((ep, ep.parameters[0]), Response(status=200, body=body3)) is None


@case
def regression_crlf_header_injection_and_xxe_live():
    """DETECT-07/08 + DISC-06 end-to-end against the live fixture: CRLF splits a second
    response header on /vuln/jsparam.php?cat (verified with a fresh header name); XXE
    fires on /vuln/stock via JS-learned XML root + error-driven storeId discovery; both
    SAFE twins stay negative."""
    import threading, os as _os, importlib.util
    from http.server import ThreadingHTTPServer
    from sentinel.orchestrator import SentinelScanner, ScanConfig
    spec = importlib.util.spec_from_file_location(
        "vulnapp_gj2", _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "fixtures", "vulnapp.py"))
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    port = 8794
    srv = ThreadingHTTPServer(("127.0.0.1", port), mod.Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        cfg = ScanConfig(allow_private=True, max_pages=30, timeout=5, seed="crlf-xxe-regression")
        sc = SentinelScanner(f"http://127.0.0.1:{port}", cfg)
        rep = sc.run()
        types = {}
        for f in rep["findings"]:
            key = (f["type"], f["url"].split("?")[0], f.get("parameter"))
            types[key] = f.get("confidence", 0)
        assert any(t == "http_response_header_injection" and "/vuln/jsparam.php" in u and p == "cat"
                   for (t, u, p) in types), "CRLF header injection must be found and verified"
        assert any(t == "xxe" and "/vuln/stock" in u and p == "storeId"
                   for (t, u, p) in types), "XXE must be found via JS-learned XML root + storeId"
        # negatives: safe twins AND the BLIND twin must NOT appear as verified findings
        for (t, u, p) in types:
            if t in ("http_response_header_injection", "xxe") and ("/safe/" in u or "/blind/" in u):
                raise AssertionError(f"false positive on safe/blind endpoint: {t} @ {u} {p}")
        # rejected list must not contain the vuln endpoints either (they are true)
        for f in rep["rejected_candidates"]:
            if f["type"] == "xxe" and "/vuln/stock" in f["endpoint_url"]:
                raise AssertionError("XXE on vulnerable stock was rejected (verification regression)")
    finally:
        srv.shutdown(); srv.server_close()


@case
def regression_vuln_js_dependency_passive():
    """PASSIVE-02 regression (ginandjuice.shop angular_1-7-7.js): served EOL AngularJS
    asset paths are flagged as vulnerable_js_dependency from the asset URL alone."""
    from sentinel.core import Endpoint, EventBus
    from sentinel.http_engine import Response
    from sentinel.detect import passive_audit
    ep = Endpoint(url="https://x.invalid/resources/js/angular_1-7-7.js")
    resp = Response(status=200, headers={"content-type": "application/javascript"}, body="stub")
    finds = passive_audit(ep, resp)
    assert any(f.type == "vulnerable_js_dependency" for f in finds), "AngularJS 1.x asset must be flagged"
    # negative: modern/non-vulnerable asset names stay silent
    ep2 = Endpoint(url="https://x.invalid/resources/js/app-modern.js")
    finds2 = passive_audit(ep2, Response(status=200, headers={}, body=""))
    assert not any(f.type == "vulnerable_js_dependency" for f in finds2)


@case
def regression_crawl_preserves_link_query():
    """DISC-07 regression (live-caught on ginandjuice.shop): links carrying query
    strings MUST be fetched WITH their query. The old crawler queued the endpoint's
    cleaned URL (query stripped) — /catalog/product?productId=1 was fetched as
    /catalog/product (400) and every form/script on the real page stayed invisible
    (the entire XXE surface lived on product pages)."""
    import threading
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    from sentinel.discovery import DiscoveryEngine
    from sentinel.http_engine import RequestEngine
    from sentinel.core import ScopeRule, EventBus

    fetched = []
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def do_GET(self):
            fetched.append(self.path)
            if self.path == "/":
                body = '<a href="/page?pid=1">link</a>'
            elif self.path == "/page?pid=1":
                body = '<form action="/target" method="POST"><input name="x" value="1"></form>'
            else:
                body = "empty"
            b = body.encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers(); self.wfile.write(b)

    srv = ThreadingHTTPServer(("127.0.0.1", 8795), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        eng = RequestEngine(ScopeRule(allowed_hosts=["127.0.0.1"], allow_private=True), EventBus("run-disc07"), timeout=5)
        de = DiscoveryEngine(eng, max_pages=5)
        endpoints, _, _ = de.crawl("http://127.0.0.1:8795/")
        assert "/page?pid=1" in fetched, f"param'd link must be fetched WITH query, got: {fetched}"
        assert any(e.method == "POST" and e.url.endswith("/target") and any(p.name == "x" for p in e.parameters)
                   for e in endpoints), "form on the param'd page must be discovered"
    finally:
        srv.shutdown(); srv.server_close()


# ================================================================ v2.1.0 PHASE (persistence / API / OAST)
@case
def unit_oast_server_records_interactions():
    """Phase 49 unit: the OOB listener records hits keyed by interaction id; poll
    returns immediately once a hit landed, and times out cleanly when nothing calls."""
    import urllib.request
    from sentinel.oast import OastServer
    oast = OastServer()
    try:
        assert oast.poll("never-called", timeout=0.3) is None, "no callback -> timeout None"
        u = oast.url("probe-42")
        assert u.endswith("/probe-42") and u.startswith("http://127.0.0.1:")
        with urllib.request.urlopen(u, timeout=5) as r:
            assert r.status == 200
        hits = oast.poll("probe-42", timeout=2.0)
        assert hits and hits[0].get("method") == "GET", f"interaction must be recorded: {hits}"
        assert "probe-42" in oast.hits()
        # determinism: same id -> same URL (evidence stays reproducible across runs)
        assert oast.url("probe-42") == u
    finally:
        oast.stop()


@case
def regression_store_persistence_and_intelligence():
    """Phase 46 regression: SQLite persistence + cross-run intelligence. Two runs of
    the same (fake) app: recurring>0, delta one-sided; filters behave; fingerprint
    identity is query-string independent."""
    import tempfile, os as _os
    from sentinel.store import Store, finding_fingerprint
    st = Store(_os.path.join(tempfile.mkdtemp(), "reg.db"))

    def fake_run(run_id, extra_type=None, drop_type=None):
        finds = [
            {"id": "F-1", "type": "sql_injection", "severity": "critical", "status": "verified",
             "url": "http://t/vuln/sqli.php?id=1", "parameter": "id", "method": "GET",
             "confidence": 0.95, "risk": 85, "evidence": [{"kind": "db_error", "detail": "x"}],
             "verification": {"method": "m", "passed": True}},
            {"id": "F-2", "type": "xss_reflected", "severity": "high", "status": "verified",
             "url": "http://t/vuln/xss.php?q=1", "parameter": "q", "method": "GET",
             "confidence": 0.9, "risk": 70, "evidence": [{"kind": "unescaped_reflection", "detail": "y"}],
             "verification": {"method": "m", "passed": True}},
        ]
        if extra_type:
            finds.append({"id": "F-3", "type": extra_type, "severity": "low", "status": "verified",
                          "url": "http://t/vuln/new.php", "parameter": "z", "method": "GET",
                          "confidence": 0.9, "risk": 30, "evidence": [], "verification": {}})
        if drop_type:
            finds = [f for f in finds if f["type"] != drop_type]
        return {"run_id": run_id, "seed": "s", "scanner": "test", "target": "http://t",
                "stats": {"requests": 10}, "findings": finds, "rejected_candidates": []}

    st.save_run(fake_run("run-aaa"))
    st.save_run(fake_run("run-bbb"))
    rec = st.recurring()
    assert {r["type"] for r in rec} == {"sql_injection", "xss_reflected"} and \
        all(r["n_runs"] == 2 for r in rec), f"both vulns recurring: {rec}"
    d = st.delta("run-aaa", "run-bbb")
    assert d["new"] == [] and d["fixed"] == [] and len(d["recurring"]) == 2
    # run with an extra vuln + a dropped one
    st.save_run(fake_run("run-ccc", extra_type="open_redirect", drop_type="xss_reflected"))
    d2 = st.delta("run-bbb", "run-ccc")
    assert len(d2["new"]) == 1 and len(d2["fixed"]) == 1, f"new=open_redirect, fixed=xss: {d2}"
    # filters
    assert len(st.list_findings(type_="sql_injection")) == 3
    assert all(f["risk"] >= 80 for f in st.list_findings(min_risk=80))
    # fingerprint identity: query string irrelevant, param relevant
    a = finding_fingerprint("sql_injection", "GET", "http://t/x.php?id=1", "id")
    b = finding_fingerprint("sql_injection", "GET", "http://t/x.php?id=999", "id")
    assert a == b
    assert a != finding_fingerprint("sql_injection", "GET", "http://t/x.php?id=1", "q")
    # get_run round-trip
    got = st.get_run("run-ccc")
    assert got["run_id"] == "run-ccc" and len(got["findings"]) == 2


@case
def regression_report_builder_outputs():
    """Phase 47 regression: HTML report is self-contained (inline CSS, no external
    assets), carries findings + verification methods + the honesty footer."""
    import tempfile, os as _os
    from sentinel.store import Store
    from sentinel.report import build_html, build_report
    st = Store(_os.path.join(tempfile.mkdtemp(), "rep.db"))
    st.save_run({"run_id": "run-xyz", "seed": "s", "scanner": "t", "target": "http://t",
                 "stats": {"requests": 5},
                 "findings": [{"id": "F-1", "type": "sql_injection", "severity": "critical",
                               "status": "verified", "url": "http://t/v.php?id=1", "parameter": "id",
                               "method": "GET", "confidence": 0.95, "risk": 85,
                               "evidence": [{"kind": "db_error", "detail": "boom"}],
                               "verification": {"method": "oracle:replay-2round", "passed": True}}],
                 "rejected_candidates": []})
    html = build_html(st, "run-xyz")
    assert "sql_injection" in html and "oracle:replay-2round" in html and "verification-gated" in html
    assert "<style>" in html and "http://" not in html.split("<style>")[1].split("</style>")[0], \
        "CSS must be inline, no external assets"
    j = build_report(st, "")
    assert j["kind"] == "overview" and j["summary"]["runs"] == 1


@case
def regression_oob_blind_xxe_end_to_end():
    """Phase 49 E2E: the vuln class that is UNVERIFIABLE by any response oracle
    (cycling-noise responses — ginandjuice.shop live behavior) is confirmed via the
    OAST out-of-band channel: detect (oob_callback) + verify (fresh-interaction-id).
    Safe twin (DTD rejected) and response-blind twin (no http fetch) stay negative."""
    import threading, os as _os, importlib.util
    from http.server import ThreadingHTTPServer
    from sentinel.orchestrator import SentinelScanner, ScanConfig
    from sentinel.oast import OastServer
    spec = importlib.util.spec_from_file_location(
        "vulnapp_oob", _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),
                                     "fixtures", "vulnapp.py"))
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    port = 8796
    srv = ThreadingHTTPServer(("127.0.0.1", port), mod.Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    oast = OastServer()
    try:
        cfg = ScanConfig(allow_private=True, max_pages=30, timeout=5,
                         seed="oob-e2e-regression", oast=oast)
        sc = SentinelScanner(f"http://127.0.0.1:{port}", cfg)
        rep = sc.run()
        oob = [f for f in rep["findings"]
               if f["type"] == "xxe" and "/vuln/oob-stock" in f["url"]]
        assert oob, "blind XXE on /vuln/oob-stock MUST be found via OOB callback"
        f = oob[0]
        assert any(e["kind"] == "oob_callback" for e in f["evidence"]), "evidence channel must be OOB"
        assert f["verification"]["method"] == "re-test:fresh-interaction-id", f["verification"]
        assert f["verification"]["passed"] is True and f["status"] == "verified"
        # negatives: safe twin + response-blind twin (no http fetch) must stay silent
        for x in rep["findings"]:
            if x["type"] == "xxe" and ("/safe/" in x["url"] or "/blind/" in x["url"]):
                raise AssertionError(f"OOB false positive: {x['url']}")
        # the response-oracle twin still verifies the classic way (regression guard)
        assert any(f["type"] == "xxe" and "/vuln/stock" in f["url"]
                   and f["verification"]["method"] == "re-test:fresh-entity-files"
                   for f in rep["findings"]), "response-oracle XXE path must not regress"
    finally:
        oast.stop(); srv.shutdown(); srv.server_close()


# ================================================================ v2.4.0 PHASE (public OAST channel)
def _fake_webhook_service(port: int):
    """Hermetic webhook.site-protocol double: POST /token issues uuid channels;
    any hit on /<token> is recorded with method/ip/ua; GET /token/<t>/requests
    serves the log page. Same wire shapes as the live service (proven 2026-09)."""
    import json as _json
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

    log: dict[str, list[dict]] = {"next_uuid": 1, "entries": []}   # entries: (token, entry)

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _json(self, code, obj):
            b = _json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            self.wfile.write(b)

        def do_POST(self):
            if self.path == "/token":
                tok = f"tok-{log['next_uuid']:04d}"
                log["next_uuid"] += 1
                self._json(201, {"uuid": tok})
            else:
                self._json(404, {})

        def do_GET(self):
            from urllib.parse import urlparse
            u = urlparse(self.path)
            if u.path.startswith("/token/") and u.path.endswith("/requests"):
                tok = u.path.split("/")[2]
                data = [e for (t, e) in log["entries"] if t == tok]
                self._json(200, {"total": len(data), "data": data})
            elif u.path.count("/") == 1 and len(u.path) > 1:
                tok = u.path.lstrip("/")
                log["entries"].append((tok, {
                    "uuid": f"r-{len(log['entries'])}", "method": self.command,
                    "ip": self.client_address[0], "url": self.path,
                    "user_agent": self.headers.get("User-Agent", ""),
                    "created_at": time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())}))
                self._json(200, {"ok": True})
            else:
                self._json(404, {})

    srv = ThreadingHTTPServer(("127.0.0.1", port), H)
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


@case
def unit_public_oast_provider_protocol():
    """Phase 52 unit: PublicWebhookProvider against a hermetic protocol double —
    token creation, ?i=<id> callback URLs, client-side id matching in poll(),
    collaborator-style hit attribution (method/ip/ua), and clean None on no
    callback. The poll floor is shrunk for test speed."""
    import urllib.request
    from sentinel.oast import PublicWebhookProvider
    srv = _fake_webhook_service(8798)
    try:
        p = PublicWebhookProvider(service="http://127.0.0.1:8798")
        p.POLL_FLOOR = 0.3
        assert p.channel == "public-webhook" and p._token.startswith("tok-")
        iid = "oob-unit-42"
        u = p.url(iid)
        assert f"?i={iid}" in u and u.startswith("http://127.0.0.1:8798/tok-"), u
        # simulate the TARGET's outbound fetch
        with urllib.request.urlopen(u, timeout=5) as r:
            assert r.status == 200
        hits = p.poll(iid, timeout=0.3)
        assert hits, "interaction must be matched from the service log"
        h = hits[0]
        assert h["method"] == "GET" and h["ip"] == "127.0.0.1" and h["ua"], h
        # a DIFFERENT id on the same channel must NOT match (id isolation)
        assert p.poll("oob-unit-other", timeout=0.3) is None
        # hits() groups by id (audit view)
        assert iid in p.hits()
    finally:
        srv.shutdown(); srv.server_close()


@case
def unit_make_oast_channel_policy():
    """Phase 52 unit: channel selection policy — auto picks the local listener for
    lab/private targets, the public channel for remote hosts; explicit 'public'
    fails LOUD when the service is unreachable; auto degrades HONESTLY to None."""
    from sentinel.oast import make_oast, OastServer, PublicWebhookProvider
    srv = _fake_webhook_service(8799)
    dead = "http://127.0.0.1:1"            # nothing listens -> connection refused
    try:
        # lab target -> local listener
        o = make_oast("127.0.0.1", mode="auto", service="http://127.0.0.1:8799")
        assert isinstance(o, OastServer); o.stop()
        # remote target + reachable service -> public channel
        p = make_oast("ginandjuice.shop", mode="auto", service="http://127.0.0.1:8799")
        assert isinstance(p, PublicWebhookProvider)
        # remote target + explicit public + UNREACHABLE service -> raises (loud)
        try:
            make_oast("example.com", mode="public", service=dead)
            raise AssertionError("mode=public must fail loud when the service is down")
        except Exception:
            pass
        # remote target + auto + UNREACHABLE service -> None (honest degradation,
        # scan proceeds exactly as in v2.0.x — never crashes for lack of a listener)
        assert make_oast("example.com", mode="auto", service=dead) is None
    finally:
        srv.shutdown(); srv.server_close()


@case
def regression_oob_public_channel_end_to_end():
    """Phase 52 E2E: the SAME blind-XXE flow that proved the local listener
    (regression_oob_blind_xxe_end_to_end) now runs over the PUBLIC channel
    protocol (token path + ?i= id + log polling) against a protocol double the
    fixture genuinely fetches over HTTP. Proves detector/verifier code is
    channel-agnostic: only the provider object changes."""
    import os as _os, importlib.util
    from http.server import ThreadingHTTPServer
    from sentinel.orchestrator import SentinelScanner, ScanConfig
    from sentinel.oast import PublicWebhookProvider
    spec = importlib.util.spec_from_file_location(
        "vulnapp_oob_pub", _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),
                                         "fixtures", "vulnapp.py"))
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    port = 8800
    srv = ThreadingHTTPServer(("127.0.0.1", port), mod.Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    fake = _fake_webhook_service(8801)
    p = PublicWebhookProvider(service="http://127.0.0.1:8801")
    p.POLL_FLOOR = 0.5
    try:
        cfg = ScanConfig(allow_private=True, max_pages=30, timeout=5,
                         seed="oob-public-e2e", oast=p)
        sc = SentinelScanner(f"http://127.0.0.1:{port}", cfg)
        rep = sc.run()
        oob = [f for f in rep["findings"]
               if f["type"] == "xxe" and "/vuln/oob-stock" in f["url"]]
        assert oob, "blind XXE MUST be found via the PUBLIC channel protocol"
        f = oob[0]
        assert any(e["kind"] == "oob_callback" and "from 127.0.0.1" in e["detail"]
                   for e in f["evidence"]), f"evidence must carry source attribution: {f['evidence']}"
        assert f["verification"]["method"] == "re-test:fresh-interaction-id"
        assert f["verification"]["passed"] is True and f["status"] == "verified"
        assert "channel=public-webhook" in f["verification"]["notes"], f["verification"]["notes"]
        # stats transparency: the report itself says which channel served OOB
        assert rep["stats"]["oast"]["channel"] == "public-webhook"
        assert rep["stats"]["oast"]["interactions"] >= 2, "detect + verify callbacks recorded"
        # negatives unchanged over the public channel
        for x in rep["findings"]:
            if x["type"] == "xxe" and ("/safe/" in x["url"] or "/blind/" in x["url"]):
                raise AssertionError(f"public-channel OOB false positive: {x['url']}")
    finally:
        p.stop(); fake.shutdown(); fake.server_close(); srv.shutdown(); srv.server_close()

@case
def regression_rest_api_server():
    """Phase 48 regression: the API server (in-process) serves health/UI/runs/findings,
    rejects bad input, enforces the token policy on non-loopback semantics, and a
    POST-launched scan against the local fixture persists + completes end-to-end."""
    import threading, tempfile, os as _os, json as _json, urllib.request, urllib.error
    from http.server import ThreadingHTTPServer
    from sentinel.api import ApiHandler, dashboard_html
    from sentinel.store import Store
    from sentinel.cli import ensure_fixture

    db = _os.path.join(tempfile.mkdtemp(), "api.db")
    ApiHandler.store = Store(db)
    ApiHandler.token = ""
    port = 8797
    srv = ThreadingHTTPServer(("127.0.0.1", port), ApiHandler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    fixture = ensure_fixture("http://127.0.0.1:8777")

    def api(p, method="GET", body=None, raw=False):
        req = urllib.request.Request(f"http://127.0.0.1:{port}{p}", method=method,
                                     data=_json.dumps(body).encode() if body is not None else None,
                                     headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=15) as r:
                data = r.read().decode()
                return r.status, (data if raw else _json.loads(data))
        except urllib.error.HTTPError as e:
            return e.code, _json.loads(e.read().decode())

    try:
        from sentinel.core import VERSION as _VER
        s, h = api("/api/health")
        assert s == 200 and h["status"] == "ok" and h["version"] == _VER
        s, ui = api("/", raw=True)
        assert "SENTINEL" in ui and "/api/scans" in ui
        s, e = api("/api/nope")
        assert s == 404
        s, e = api("/api/scans", "POST", {"target": "ftp://x"})
        assert s == 400
        # a tiny real scan through the API (fixture): launches async, completes, persists
        s, r = api("/api/scans", "POST", {"target": "http://127.0.0.1:8777",
                                          "max_pages": 2, "allow_private": True})
        assert s == 202 and "run_id" in r
        import time as _t
        for _ in range(120):
            s, st = api(f"/api/scans/{r['run_id']}")
            if st.get("state") in ("done", "failed"):
                break
            _t.sleep(1)
        assert st["state"] == "done", st.get("error")
        s, runs = api("/api/runs")
        assert any(x["run_id"] == r["run_id"] for x in runs["runs"]), "auto-persist failed"
        s, f = api("/api/findings")
        assert f["count"] >= 1
        s, stats = api("/api/stats")
        assert stats["summary"]["runs"] >= 1
    finally:
        srv.shutdown(); srv.server_close()
        if fixture is not None:
            fixture.terminate()
            try:
                fixture.wait(timeout=5)
            except Exception:
                fixture.kill()


@case
def regression_cli_script_mode_all_subcommands():
    """CLI smoke test in SCRIPT mode (python3 sentinel/cli.py ...): the full argument
    surface must import + parse + run. Live-caught gap: a relative import in main()
    (`from .core import ...`) crashed `scan` while every in-process test stayed green
    — only script-mode execution exposes it. Covers scan/findings/report/serve --help
    + a real script-mode mini-scan with --db persistence."""
    import subprocess, sys, tempfile, os as _os, json as _json
    root = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
    cli = _os.path.join(root, "sentinel", "cli.py")
    for args in (["scan", "--help"], ["findings", "--help"], ["report", "--help"],
                 ["serve", "--help"], ["benchmark", "--help"], ["doctor"], ["repair-demo", "--help"]):
        r = subprocess.run([sys.executable, cli, *args], capture_output=True, text=True,
                           timeout=120, cwd=root)
        assert r.returncode == 0, f"script-mode CLI failed: {args}: {r.stderr[-300:]}"
    # real script-mode mini-scan against the fixture + --db persistence round-trip
    from sentinel.cli import ensure_fixture
    fixture = ensure_fixture("http://127.0.0.1:8777")
    try:
        db = _os.path.join(tempfile.mkdtemp(), "cli.db")
        out = _os.path.join(tempfile.mkdtemp(), "scan.json")
        r = subprocess.run([sys.executable, cli, "scan", "http://127.0.0.1:8777",
                            "--allow-private", "--max-pages", "3", "--out", out, "--db", db],
                           capture_output=True, text=True, timeout=180, cwd=root)
        assert r.returncode == 0, f"script-mode scan crashed: {r.stderr[-400:]}"
        # stdout = one JSON summary object followed by human finding lines
        dec = _json.JSONDecoder()
        summary, _ = dec.raw_decode(r.stdout.lstrip())
        assert summary.get("db") == db and summary.get("persisted", 0) >= 1, summary
        from sentinel.store import Store
        assert len(Store(db).list_runs()) == 1, "scan --db must persist the run"
    finally:
        if fixture is not None:
            fixture.terminate()
            try:
                fixture.wait(timeout=5)
            except Exception:
                fixture.kill()


# ================================================================ Phase 50 (browser/DOM engine)
@case
def unit_disc10_divform_parsing():
    """JS-driven pseudo-forms are <div data-action data-method> blocks, not <form>
    elements — the exact ginandjuice.shop #subscribe markup. The parser must recover
    action+method+inputs (nested-div safe) while real <form>s stay unaffected."""
    from sentinel.discovery import _LinkParser
    html = """<html><body>
<div id="subscribe" class="form" data-method="post" data-action="/catalog/subscribe">
  <input required type=email name=email placeholder="Email address">
  <input required type=hidden name=csrf value="ABC123">
  <button class="button" type=submit>Subscribe</button>
</div>
<form action="/old" method="GET"><input name=q value="1"></form>
</body></html>"""
    p = _LinkParser(); p.feed(html)
    assert p.divforms and p.divforms[0]["action"] == "/catalog/subscribe"
    assert p.divforms[0]["method"] == "POST"
    assert [n for n, _ in p.divforms[0]["params"]] == ["email", "csrf"], p.divforms[0]
    assert p.forms and p.forms[0]["params"] == [("q", "1")], "real forms must not regress"
    # csrf params must classify as TOKEN (never mutated, carried as sibling)
    from sentinel.core import Parameter, ParamKind
    assert Parameter("csrf", ParamLocation.BODY, "ABC123").classify().kind == ParamKind.TOKEN
    assert Parameter("authenticity_token", ParamLocation.BODY, "x").classify().kind == ParamKind.TOKEN


@case
def unit_disc11_dom_sink_scanner():
    """Static source->sink analysis: the ginandjuice.shop /blog?search pattern
    (URLSearchParams -> document.write) is identified with its param name;
    safe textContent sinks produce NO candidate (precision)."""
    from sentinel.browser import scan_dom_sinks, scan_html_dom_sinks
    js = """function trackSearch(query) {
    document.write('<img src="/resources/images/tracker.gif?searchTerms='+query+'">');
}
var query = (new URLSearchParams(window.location.search)).get('search');
if(query) { trackSearch(query); }"""
    sinks = scan_dom_sinks("https://t.example/blog", js)
    assert any(s.sink == "document.write" and s.params == ["search"] and s.source == "search"
               for s in sinks), sinks
    safe = """var q = new URLSearchParams(window.location.search).get('search');
if(q){ document.getElementById('out').textContent = q; }"""
    assert scan_dom_sinks("https://t.example/safe", safe) == [], "textContent is not a dangerous sink"
    # hash-source page (location.hash -> innerHTML) is a candidate too
    h = "var h = location.hash.substring(1); document.getElementById('x').innerHTML = h;"
    hs = scan_dom_sinks("https://t.example/hash", h)
    assert any(s.source == "hash" and s.sink == "innerHTML" for s in hs), hs
    # inline-block extraction works on full HTML pages
    page = f"<html><body><script>{js}</script></body></html>"
    assert len(scan_html_dom_sinks("u", page)) >= 1


@case
def unit_eng04_json_body_render():
    """ENG-04: params with JSON location render as a JSON body with
    Content-Type application/json — the request shape subscribeNow-style JS
    produces. Siblings (CSRF tokens) ride along verbatim."""
    import json as _json
    from sentinel.core import Endpoint, Parameter, ParamLocation
    from sentinel.http_engine import RequestEngine, RequestMutation, RequestMutation as RM
    from sentinel.core import ScopeRule, EventBus
    eng = RequestEngine(ScopeRule(allowed_domains=["t.example"], allow_private=False), EventBus("t"))
    ep = Endpoint(url="http://t.example/subscribe", method="POST", parameters=[
        Parameter("email", ParamLocation.JSON, "a@b.example"),
        Parameter("csrf", ParamLocation.JSON, "TOK123"),
    ])
    url, method, headers, body = eng._render(
        RM(endpoint=ep, param_name="email", param_value="<img src=x onerror=1>"))
    sent = _json.loads(body)
    assert sent == {"email": "<img src=x onerror=1>", "csrf": "TOK123"}, sent
    assert headers.get("Content-Type") == "application/json", headers
    assert method == "POST"
    # form-body endpoints keep the urlencoded Content-Type (no regression)
    ep2 = Endpoint(url="http://t.example/login", method="POST", parameters=[
        Parameter("uid", ParamLocation.BODY, "admin")])
    _, _, h2, b2 = eng._render(RM(endpoint=ep2, param_name="uid", param_value="admin' -- "))
    assert h2.get("Content-Type") == "application/x-www-form-urlencoded"
    assert "uid=" in b2


@case
def unit_eng05_cookie_jar_session_continuity():
    """ENG-05: Set-Cookie harvested from a response is replayed on the next
    same-host request — without the jar the CSRF-protected endpoint answers 403
    for every request (the whole surface unreachable), with it the flow works."""
    import threading, os as _os, importlib.util
    from http.server import ThreadingHTTPServer
    from sentinel.core import Endpoint, Parameter, ParamLocation, ScopeRule, EventBus
    from sentinel.http_engine import RequestEngine, RequestMutation
    from sentinel.core import ParamKind
    spec = importlib.util.spec_from_file_location(
        "vulnapp_cj", _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),
                                    "fixtures", "vulnapp.py"))
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    port = 8797
    srv = ThreadingHTTPServer(("127.0.0.1", port), mod.Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        def mk_engine():
            return RequestEngine(ScopeRule(allowed_domains=["127.0.0.1"], allow_private=True),
                                 EventBus("cj"))
        # 1) without visiting the form page first: no session, no token -> 403
        e0 = mk_engine()
        ep0 = Endpoint(url=f"http://127.0.0.1:{port}/vuln/csrf-reflect", method="POST", parameters=[
            Parameter("note", ParamLocation.JSON, "x"), Parameter("csrf", ParamLocation.JSON, "WRONG")])
        r0 = e0.send(RequestMutation(endpoint=ep0, param_name="note", param_value="x",
                                     extra_headers={"Content-Type": "application/json"},
                                     body_override='{"note":"x","csrf":"WRONG"}'))
        assert r0.status == 403, f"expected 403 without session, got {r0.status}"
        # 2) with the jar: GET the form page (sets cookie, page embeds token),
        #    then POST with harvested session + token -> 200 reflection
        e1 = mk_engine()
        page = e1.send(RequestMutation(
            endpoint=Endpoint(url=f"http://127.0.0.1:{port}/vuln/csrfdivform")))
        assert "session" in e1.cookie_jar.get("127.0.0.1", {}), e1.cookie_jar
        import re as _re
        tok = _re.search(r'name="csrf" value="([0-9a-f]+)"', page.body).group(1)
        ep1 = Endpoint(url=f"http://127.0.0.1:{port}/vuln/csrf-reflect", method="POST", parameters=[
            Parameter("note", ParamLocation.JSON, "zk51probe"),
            Parameter("csrf", ParamLocation.JSON, tok)])
        r1 = e1.send(RequestMutation(endpoint=ep1, param_name="note", param_value="zk51probe"))
        assert r1.status == 200 and "zk51probe" in r1.body, (r1.status, r1.body[:80])
    finally:
        srv.shutdown(); srv.server_close()


@case
def e2e_browser_phase_full():
    """Phase 50 E2E (real Chromium): the four browser-phase ground truths in ONE
    full scan — DOM XSS proven by execution + fresh-canary re-probe (BR-01),
    div-form JSON reflection (DISC-10+ENG-04), CSRF-protected reflection (ENG-05),
    runtime-built form (render-merge) — while both safe twins stay silent (0 FP)."""
    import threading, os as _os, importlib.util
    from http.server import ThreadingHTTPServer
    from sentinel.orchestrator import SentinelScanner, ScanConfig
    from sentinel.browser import browser_available
    if not browser_available():
        raise AssertionError("playwright/chromium required for the Phase 50 E2E gate "
                             "(doctor check browser_engine reports availability)")
    spec = importlib.util.spec_from_file_location(
        "vulnapp_br", _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),
                                    "fixtures", "vulnapp.py"))
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    port = 8798
    srv = ThreadingHTTPServer(("127.0.0.1", port), mod.Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        cfg = ScanConfig(allow_private=True, max_pages=30, timeout=6,
                         seed="phase50-e2e", browser=True)
        sc = SentinelScanner(f"http://127.0.0.1:{port}", cfg)
        rep = sc.run()
        got = {(f["type"], f["url"].split("?")[0], f["parameter"]): f for f in rep["findings"]}
        # (1) DOM XSS via document.write — browser-only, execution-proven, BR-01 verified
        dom = got.get(("xss_dom", f"http://127.0.0.1:{port}/vuln/dom-write", "search"))
        assert dom, f"xss_dom missing; got {sorted(got)}"
        assert dom["verification"]["method"] == "re-probe:fresh-canary"
        assert dom["verification"]["passed"] is True and dom["status"] == "verified"
        # (2) div-form JSON reflection (subscribe-style chain)
        assert ("xss_reflected", f"http://127.0.0.1:{port}/vuln/json-reflect", "name") in got, \
            f"div-form JSON chain missing; got {sorted(got)}"
        # (3) CSRF-protected reflection (cookie jar + token preservation)
        assert ("xss_reflected", f"http://127.0.0.1:{port}/vuln/csrf-reflect", "note") in got, \
            f"CSRF-protected surface missing; got {sorted(got)}"
        # (4) runtime-built form (statically invisible — render-merge only)
        assert ("xss_reflected", f"http://127.0.0.1:{port}/vuln/jsform-reflect", "msg") in got, \
            f"runtime form surface missing; got {sorted(got)}"
        # negatives: safe DOM sink + escaped JSON reflection must stay silent
        for t, u, p in got:
            if t == "xss_dom" and "/safe/dom-text" in u:
                raise AssertionError("FP: safe textContent sink flagged")
            if t == "xss_reflected" and "/safe/json-reflect" in u:
                raise AssertionError("FP: escaped JSON reflection flagged")
        assert rep["stats"].get("browser_pages", 0) > 0, "browser render pass must run"
    finally:
        srv.shutdown(); srv.server_close()


# ================================================================ main
# ---- Phase 51 (authenticated scanning) unit + regression suite

@case
def unit_eng06_body_serialization_without_mutation():
    """ENG-06 (live-caught on demo.testfire.net/doLogin): a POST endpoint with
    BODY/JSON params but NO mutation target (baseline fetch, login request)
    used to go out with an EMPTY body — credentials transmitted as nothing.
    The engine must serialize the endpoint's own body fields in both encodings."""
    from sentinel.http_engine import RequestEngine, RequestMutation
    eng = RequestEngine(ScopeRule(allowed_domains=["x.local"]), EventBus("t-eng06"), timeout=2)
    ep = Endpoint(url="http://x.local/doLogin", method="POST", parameters=[
        Parameter("uid", ParamLocation.BODY, "jsmith"),
        Parameter("passw", ParamLocation.BODY, "demo1234")])
    _, _, h, body = eng._render(RequestMutation(endpoint=ep))
    assert body == "uid=jsmith&passw=demo1234", body
    assert h.get("Content-Type") == "application/x-www-form-urlencoded", h.get("Content-Type")
    # JSON-location variant (ENG-04 semantics for plain sends)
    ep2 = Endpoint(url="http://x.local/api/login", method="POST", parameters=[
        Parameter("user", ParamLocation.JSON, "a"), Parameter("pw", ParamLocation.JSON, "b")])
    _, _, h2, body2 = eng._render(RequestMutation(endpoint=ep2))
    import json as _j
    assert _j.loads(body2) == {"user": "a", "pw": "b"}, body2
    assert h2.get("Content-Type") == "application/json", h2.get("Content-Type")


@case
def unit_eng07_cookie_refresh_across_redirect_hops():
    """ENG-07 (live-caught via the fixture-v5 login rotation): cookies issued ON
    a 302 response (Set-Cookie on the login POST) must reach the redirect hop
    target — the old code replayed the ORIGINAL Cookie header, so the hop
    arrived anonymous and bounced back to the gate."""
    import threading
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    from sentinel.http_engine import RequestEngine, RequestMutation
    seen = {}
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def _r(self, code, loc="", cookie=""):
            self.send_response(code)
            if loc: self.send_header("Location", loc)
            if cookie: self.send_header("Set-Cookie", cookie)
            self.send_header("Content-Length", "0"); self.end_headers()
        def do_POST(self):
            self.rfile.read(int(self.headers.get("Content-Length") or 0))
            self._r(302, "/land", "AUTH=granted-xyz; Path=/")
        def do_GET(self):
            seen["cookie_on_land"] = self.headers.get("Cookie") or ""
            if "AUTH=granted-xyz" in seen["cookie_on_land"]:
                self._r(200)
            else:
                self._r(302, "/login")
    srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
    port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        eng = RequestEngine(ScopeRule(allowed_domains=["127.0.0.1"], allow_private=True),
                            EventBus("t-eng07"), timeout=5)
        ep = Endpoint(url=f"http://127.0.0.1:{port}/doLogin", method="POST", parameters=[
            Parameter("uid", ParamLocation.BODY, "u"), Parameter("passw", ParamLocation.BODY, "p")])
        r = eng.send(RequestMutation(endpoint=ep))
        assert r.status == 200, (r.status, seen)
        assert "AUTH=granted-xyz" in seen["cookie_on_land"], seen
    finally:
        srv.shutdown(); srv.server_close()


@case
def unit_auth01_form_intelligent_login():
    """AUTH-01: the login form's session-bound CSRF token changes every GET —
    a login that hard-codes fields can never pass; the engine must harvest the
    form (action + hidden token) and succeed in one flow."""
    import threading, os as _os, importlib.util
    from http.server import ThreadingHTTPServer
    from sentinel.http_engine import RequestEngine
    from sentinel.auth import AuthProfile, AuthEngine
    spec = importlib.util.spec_from_file_location(
        "vulnapp_a1", _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),
                                    "fixtures", "vulnapp.py"))
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    srv = ThreadingHTTPServer(("127.0.0.1", 0), mod.Handler)
    port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        eng = RequestEngine(ScopeRule(allowed_domains=["127.0.0.1"], allow_private=True),
                            EventBus("t-a1"), timeout=5)
        ok = AuthEngine(AuthProfile(login_url=f"http://127.0.0.1:{port}/login",
                                    username="demo", password="demo123",
                                    success_marker="Sign Off"), eng, EventBus("t-a1")).login()
        assert ok, "form-intelligent login must succeed"
        # wrong credentials -> deterministic rejection (AUTH-02 negative)
        eng2 = RequestEngine(ScopeRule(allowed_domains=["127.0.0.1"], allow_private=True),
                             EventBus("t-a1b"), timeout=5)
        ae2 = AuthEngine(AuthProfile(login_url=f"http://127.0.0.1:{port}/login",
                                     username="demo", password="WRONG",
                                     success_marker="Sign Off"), eng2, EventBus("t-a1b"))
        assert not ae2.login() and "rejected" in ae2.state.last_error, ae2.state.last_error
    finally:
        srv.shutdown(); srv.server_close()


def _spawn_fixture(name, port, auth_ttl=0):
    import threading, os as _os, importlib.util
    from http.server import ThreadingHTTPServer
    spec = importlib.util.spec_from_file_location(
        name, _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),
                            "fixtures", "vulnapp.py"))
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    if auth_ttl:
        mod.AUTH_TTL = auth_ttl
    srv = ThreadingHTTPServer(("127.0.0.1", port), mod.Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


@case
def regression_auth_scan_finds_gated_surface_and_anonymous_does_not():
    """Phase 51 E2E gate: with credentials the scanner logs in (AUTH-01/02),
    crawls the authenticated landing, and finds BOTH auth-gated TPs
    (/account?q raw reflection, /vault/transfer?acct boolean SQLi) with the
    escaped /account?tab twin staying silent; the SAME scan without
    credentials finds NONE of the gated surface (negative control)."""
    from sentinel.orchestrator import SentinelScanner, ScanConfig
    from sentinel.auth import AuthProfile
    port = 8801
    srv = _spawn_fixture("vulnapp_auth_e2e", port)
    try:
        cfg = ScanConfig(allow_private=True, max_pages=25, timeout=6,
                         seed="phase51-e2e", browser=False,
                         auth=AuthProfile(login_url=f"http://127.0.0.1:{port}/login",
                                          username="demo", password="demo123",
                                          success_marker="Sign Off"))
        rep = SentinelScanner(f"http://127.0.0.1:{port}", cfg).run()
        got = {(f["type"], f["url"].split("?")[0], f["parameter"]) for f in rep["findings"]}
        base = f"http://127.0.0.1:{port}"
        assert rep["stats"]["auth"]["authenticated"] is True, rep["stats"].get("auth")
        assert ("xss_reflected", f"{base}/account", "q") in got, f"auth-gated XSS missing: {sorted(got)[:8]}"
        assert ("sql_injection", f"{base}/vault/transfer", "acct") in got, f"auth-gated SQLi missing: {sorted(got)[:8]}"
        assert ("xss_reflected", f"{base}/account", "tab") not in got, "FP: escaped auth twin flagged"
        # ---- anonymous negative control: same target, no credentials
        cfg2 = ScanConfig(allow_private=True, max_pages=25, timeout=6,
                          seed="phase51-anon", browser=False)
        rep2 = SentinelScanner(f"http://127.0.0.1:{port}", cfg2).run()
        got2 = {(f["type"], f["url"].split("?")[0], f["parameter"]) for f in rep2["findings"]}
        assert ("xss_reflected", f"{base}/account", "q") not in got2, "gated surface must be invisible anonymously"
        assert ("sql_injection", f"{base}/vault/transfer", "acct") not in got2, "gated SQLi must be invisible anonymously"
    finally:
        srv.shutdown(); srv.server_close()


@case
def regression_auth03_watchdog_reauth_midscan():
    """AUTH-03: the server expires sessions after N authenticated requests
    (AUTH_TTL); mid-scan session loss must self-heal (re-login + replay) and
    the auth-gated TPs must STILL be found — degradation without false
    positives, exactly like OP-01's spirit but for transport identity."""
    from sentinel.orchestrator import SentinelScanner, ScanConfig
    from sentinel.auth import AuthProfile
    port = 8802
    srv = _spawn_fixture("vulnapp_ttl", port, auth_ttl=30)
    try:
        p = AuthProfile(login_url=f"http://127.0.0.1:{port}/login",
                        username="demo", password="demo123",
                        success_marker="Sign Off", max_reauth=25)
        cfg = ScanConfig(allow_private=True, max_pages=25, timeout=6,
                         seed="phase51-ttl", browser=False, auth=p)
        rep = SentinelScanner(f"http://127.0.0.1:{port}", cfg).run()
        auth = rep["stats"]["auth"]
        assert auth["reauths"] >= 1, f"watchdog must re-authenticate: {auth}"
        got = {(f["type"], f["url"].split("?")[0], f["parameter"]) for f in rep["findings"]}
        base = f"http://127.0.0.1:{port}"
        assert ("xss_reflected", f"{base}/account", "q") in got, "gated XSS lost after expiry"
        assert ("sql_injection", f"{base}/vault/transfer", "acct") in got, "gated SQLi lost after expiry"
        assert ("xss_reflected", f"{base}/account", "tab") not in got, "FP after session churn"
    finally:
        srv.shutdown(); srv.server_close()


def main():
    suite = sys.argv[1] if len(sys.argv) > 1 else "all"
    RESULTS["suite"] = suite
    if suite != "all":
        RESULTS["cases"] = [c for c in RESULTS["cases"] if c["name"].startswith(suite)]
        RESULTS["total"] = len(RESULTS["cases"])
        RESULTS["failed"] = sum(1 for c in RESULTS["cases"] if not c["ok"])
    RESULTS["passed"] = RESULTS["failed"] == 0
    print(json.dumps(RESULTS, indent=1))
    sys.exit(0 if RESULTS["passed"] else 1)


if __name__ == "__main__":
    main()
