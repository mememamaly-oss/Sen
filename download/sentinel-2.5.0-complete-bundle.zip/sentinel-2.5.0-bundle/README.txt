SENTINEL v2.5.0 — COMPLETE BUNDLE
=================================
sentinel-2.5.0-source.zip   self-sufficient source (16 modules: 9 detectors incl.
                            SSRF/command-injection/CORS, browser/DOM engine, auth
                            engine, OAST local+public providers, fixtures v6,
                            52-test suite, ground truth v6, CHANGELOG)
sentinel-results/           every real-target scan (v2.0.0 -> v2.5.0), full benchmark
                            evolution, repair campaigns, reports, sentinel.db,
                            strategy store, ground truth, WORKLOG
Quick start: unzip source -> python -m sentinel.cli doctor
             python -m sentinel.cli benchmark
             python -m sentinel.cli scan https://<authorized-target> --oast public
