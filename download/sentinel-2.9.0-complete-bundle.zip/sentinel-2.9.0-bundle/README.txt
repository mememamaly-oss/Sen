SENTINEL v2.9.0 — COMPLETE BUNDLE ("Credential Intelligence" Release)
====================================================================
sentinel-2.9.0-source.zip   self-sufficient source: 27-module engine incl.
                           the Credential Vault (ChaCha20+HMAC encrypt-then-
                           MAC, pure stdlib), the 10-command vault CLI group,
                           .gitignore-vault template, fixture v8, 69-test
                           suite, ground truth v8 (30 TP / 24 TN).
                           Self-check: doctor 14/14 + script-mode vault CLI
                           + phase57 vault unit battery + benchmark F1=1.000
                           deterministic (run-3c0652b6be).
sentinel-results/           every real-target artifact of the campaign,
                           incl. the v2.9.0 testfire live scan with an ARMED
                           vault (673 req, 74 verified, 0 rejected, credential
                           exposure = 0 — an honest negative), the encrypted
                           vault artifact + its audit trail, and the
                           multi-party authorization demonstration
                           (org-owner key authorized; key files NEVER ship
                           with deliverables).
.gitignore-vault            copy into your repo BEFORE creating any vault.
CHANGELOG.md / WORKLOG.md   release notes + the full build history.
