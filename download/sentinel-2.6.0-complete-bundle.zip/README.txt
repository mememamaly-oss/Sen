SENTINEL v2.6.0 — complete bundle
=================================
Deterministic DAST platform. Pure Python 3 stdlib, zero dependencies.
Every finding is verification-gated (independent replay before it counts).

Contents
--------
sentinel-2.6.0-source.zip   the full source tree (self-check: doctor 12/12,
                            benchmark F1=1.000 TP=22 FP=0 FN=0 TN=16 from the
                            extracted zip)
sentinel-results/           live evidence archive:
  scan_ginjuice_v260.json     production scan of the authorized target
                              (ginandjuice.shop) with v2.6.0 — 45 verified,
                              0 FP, incl. the NEW AngularJS {{expression}}
                              reflection found by the DETECT-14 battery
  scan_ginjuice_v260.sarif    the same run as a SARIF 2.1.0 log (34 results)
  live_validation_v260.json   the full Phase-54 live-validation evidence bundle
  benchmark_v260_det1/2/3.json  determinism proof — three identical runs
  sentinel_v260.db            SQLite store of the production run
  CHANGELOG.md / WORKLOG.md   release notes + multi-agent work log
  (earlier sentinel-results files = the historical v2.0-v2.5 evidence chain)

v2.6.0 highlights
-----------------
+ Passive WAF + technology fingerprinting (zero extra requests, evidence-backed,
  honest nulls) — stats.fingerprint in every report
+ DETECT-14 context-adaptive XSS battery (tag-filtered -> attr injection;
  ng-app -> {{expression}} vector) — found a real Angular reflection live
+ ENG-09: 429/503 exponential backoff, Retry-After honored, honest final answer
+ AUTH-05: Bearer/API-key/custom-header scanning with honest rejection counting
+ DISC-13: OpenAPI/Swagger seeding (auto-probe + explicit spec)
+ OP-02: SARIF 2.1.0 export (CLI + REST) — verification-gated, stable rule ids

Quick start
-----------
unzip sentinel-2.6.0-source.zip && cd sentinel-2.6.0
python -m sentinel.cli doctor
python -m sentinel.cli benchmark            # auto-spawns the local fixture
python -m sentinel.cli scan http://target --auth-token "..." --db run.db
python -m sentinel.cli report --db run.db --format sarif --out run.sarif
