# SENTINEL 2.1.0 — Complete Bundle

Deterministic self-healing DAST platform + full real-test campaign artifacts.

## Contents
- source/            Full platform source (13 modules, fixtures, 36-case test suite, ground truth)
- results/scans/     All real-target scans (testasp, testaspnet, testfire/Altoro, ginandjuice/PortSwigger)
- results/benchmarks/ Benchmark evolution v1 -> v2.1.0 (F1 0.833 -> 1.000) + repair candidates + repro
- results/reports/   HTML + PDF reports (Arabic + English)
- database/          sentinel.db (SQLite runs+findings store) + strategy_store.json
- docs/              WORKLOG.md (full build/fix history) + CHANGELOG.md

## Quick start
    cd source
    python3 sentinel/cli.py doctor
    python3 sentinel/cli.py benchmark          # F1=1.000 expected (auto-starts fixture)
    python3 sentinel/cli.py scan <authorized-target> --max-pages 25 --out results/scan.json
    python3 sentinel/cli.py serve              # REST API + dashboard at http://127.0.0.1:8787

Only scan targets you are explicitly authorized to test.
