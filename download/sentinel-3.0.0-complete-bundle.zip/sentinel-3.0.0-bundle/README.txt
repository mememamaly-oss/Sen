SENTINEL v3.0.0 — Workflow Intelligence — COMPLETE BUNDLE
=======================================================
Contents:
  sentinel-3.0.0-source.zip   the full platform source (pure Python 3 stdlib)
  CHANGELOG.md                every release, v1.0.0 -> v3.0.0
  WORKLOG.md                  the complete engineering work log
  .gitignore-vault            vault/key ignore template (Credential Vault)
  sentinel-results/           canonical artifacts:
      tests_v300_FULL.json      71/71 gates (unit + regression + chaos)
      doctor_v300.json          15/15 self-checks (incl. workflow_engine)
      benchmark_v300_det1..3    F1 = 1.000 deterministic x3
                                (35 TP / 0 FP / 0 FN / 29 TN, run-3c0652b6be)
      scan_testfire_v300_LIVE  light production scan, learn-only workflow:
                                honest negative /bank:chain_too_short,
                                95 verified / 0 rejected, prior classes intact
      ground_truth.json         v9 (64 rows: +5 business-logic TP, +5 TN)

What v3.0.0 adds: Business-Logic / Workflow Intelligence — the scanner
reasons about PROCESSES, not just requests. It learns multi-step flows by
guided walks (chain, resource linkage, state oracle, execution markers) and,
only with --logic-active, tests the five invariants: step bypass, out-of-
order execution, post-approval value tamper, duplicate execution, and
declared-privilege escalation. Every finding requires STATE-ORACLE PROOF
(VR-20): a server that merely fails to reject is never a finding.

Self-check (from this bundle):  unzip the source zip, then
  python3 sentinel/cli.py doctor                      -> 15/15
  python3 sentinel/cli.py benchmark                   -> F1 = 1.000
