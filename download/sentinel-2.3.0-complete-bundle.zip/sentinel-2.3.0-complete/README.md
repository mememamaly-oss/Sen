# SENTINEL 2.3.0 — Complete Bundle

Deterministic self-healing DAST platform + full real-test campaign artifacts.
Phase 51 (v2.3.0): authenticated scanning — form-intelligent login (session-bound
CSRF), session-loss watchdog with budget-capped re-auth + single replay, browser
session continuity, ENG-06/ENG-07 transport fixes. Real-target proof:
demo.testfire.net authenticated scan (jsmith demo account) reached 10 /bank/*
endpoints invisible anonymously and verified 4 NEW findings incl. CRITICAL SQLi
on /bank/ccApply — session expired 3x mid-scan, self-healed every time.

## Contents
- source/            Full platform source (15 modules incl. auth.py, fixtures v5,
                     46-case test suite, ground truth 19TP/13TN)
- results/scans/     All real-target scans (testasp, testaspnet, testfire/Altoro
                     incl. AUTHENTICATED v2.3.0 run, ginandjuice/PortSwigger)
- results/benchmarks/Full benchmark evolution v1 -> v5 (F1=1.000 at every step)
- results/reports/   HTML + PDF reports
- database/          sentinel.db (all persisted runs) + strategy store
- docs/              WORKLOG + CHANGELOG

## Verify (60s)
cd source && python -m sentinel.cli doctor     # 11/11
python -m sentinel.cli benchmark               # F1=1.000 TP=19 FP=0 FN=0 TN=13 (authenticated scan)
python tests/run_tests.py                      # 46/46

## Quality state
- 46/46 tests, 11/11 doctor, F1=1.000 deterministic x3 (run-3c0652b6be)
- Real targets: 4 platforms, 19 verified actives, 0 false positives
