"""SENTINEL v2.8.0 — Evidence Graph & Impact Assessment (Phase 56).

Every verified finding already carries its raw evidence chain and its
verification record. This module turns those parts into two professional
artifacts:

  1. IMPACT PROOF — a per-class statement of what the vulnerability lets an
     attacker DO, with the grade:
       * "proven"      — the scan demonstrated the impact itself, safely
                         (differential oracles, OOB callbacks, marker reads).
       * "indicated"   — the defect is confirmed but impact was not directly
                         exercised (banner/passive classes).
     The statements are class-accurate and NON-DESTRUCTIVE by construction:
     SENTINEL proves capability (a boolean oracle flips, a callback arrives,
     a computed value appears, a victim's marker is readable) without ever
     extracting real data, writing state, or executing destructive payloads.

  2. CHAIN OF CUSTODY — an ordered, auditable chain from detection to proof:
     request -> evidence -> verification -> impact. The chain rides every
     finding dict (additive "impact" key), so a report reader can walk from
     the vulnerability to exactly what proved it.
"""
from __future__ import annotations

# type -> (grade, impact statement). Statements describe demonstrated
# capability, phrased for report consumers (not payload recipes).
IMPACT_PROFILES: dict[str, tuple[str, str]] = {
    "sql_injection":
        ("proven", "Attacker influence over query evaluation proven by a "
         "non-destructive boolean differential (AND 1=1 vs AND 1=2 yield "
         "different application behavior) — a read-capable oracle. Data was "
         "never extracted; the capability was demonstrated, not exercised."),
    "xss_reflected":
        ("proven", "Arbitrary attacker-supplied markup/JavaScript survives "
         "into the response in an executable context (canary proven) — "
         "session theft, credential capture and action forgery in the victim's "
         "browser are reachable without further preconditions."),
    "xss_dom":
        ("proven", "Attacker-controlled data reaches a dangerous DOM sink and "
         "EXECUTES in a real browser (execution probe fired) — client-side "
         "code execution in victims' sessions."),
    "path_traversal":
        ("proven", "File reads outside the document root proven with a "
         "marker file — arbitrary local file disclosure (configuration, "
         "secrets, source) is reachable."),
    "xxe":
        ("proven", "External entity resolution proven (file content reached "
         "the response, or an out-of-band fetch arrived from the target's own "
         "infrastructure) — local file disclosure and SSRF-via-parser."),
    "ssrf":
        ("proven", "The server made an outbound request to an attacker-chosen "
         "URL, proven by an out-of-band callback from the target's "
         "infrastructure — internal service/metadata access is reachable."),
    "command_injection":
        ("proven", "Operating-system command execution proven by a "
         "non-destructive out-of-band callback fired from the target host "
         "(chained network fetch) — full host-level impact."),
    "ssti":
        ("proven", "Server-side template EVALUATION proven: a fresh "
         "arithmetic expression was computed by the target (49/132-style "
         "oracle) — template-engine code execution context."),
    "nosql_injection":
        ("proven", "Query operator injection proven: an attacker-supplied "
         "$operator object flipped an authentication rejection into "
         "acceptance — authentication bypass."),
    "csrf":
        ("proven", "A state-changing request from a hostile origin was "
         "accepted exactly like a same-origin one (fresh-origin replay) — "
         "silent cross-site action forgery against authenticated users."),
    "jwt_security":
        ("proven", "Unsigned token issuance (alg=none, empty signature) "
         "reproduced on a fresh request — any party can forge arbitrary "
         "claims if the verifier honors the declared algorithm."),
    "host_header_injection":
        ("proven", "An attacker-controlled Host header value is reflected "
         "into application output (fresh canary host) — password-reset "
         "poisoning and cache-poisoning preconditions."),
    "idor_bola":
        ("proven", "Object-level access control broken: a low-privilege "
         "session retrieved ANOTHER account's private data (victim marker "
         "present in the attacker's response, reproduced with a fresh "
         "victim) — cross-user data exposure."),
    "vertical_privilege_escalation":
        ("proven", "Role boundary broken: a low-privilege session received "
         "the privileged (admin-only) view of a protected surface, "
         "reproduced on a fresh replay — full administrative capability "
         "reachable without the privileged role."),
    "business_logic_step_bypass":
        ("proven", "Business-process order broken: a later step of a learned "
         "multi-step flow created its object although the mandatory "
         "predecessor step never ran (state-oracle proof) — the process "
         "sequence is not enforced server-side."),
    "business_logic_out_of_order":
        ("proven", "Business-process order broken: the FINAL step of a "
         "learned flow EXECUTED a resource that was never created (implicit "
         "creation from request parameters, state-oracle proof) — the "
         "producing step can be skipped entirely."),
    "business_logic_value_tamper":
        ("proven", "Approval binding broken: a value approved at creation "
         "time was REPLACED at execution time (tampered canary visible in "
         "the executed state-oracle record) — execution re-trusts request "
         "data instead of the approved record."),
    "business_logic_duplicate_execution":
        ("proven", "Idempotency broken: replaying the final step of a "
         "learned flow executed the same resource TWICE (state-oracle "
         "occurrence proof) — repeat-submission double-spend class."),
    "business_logic_privilege_escalation":
        ("proven", "Declared privilege not enforced: an option the UI itself "
         "labels privileged ('admin only') was EXECUTED by a lower-privilege "
         "session (state-oracle proof) — the workflow privilege boundary "
         "exists only in the interface, not on the server."),
    "business_logic_cross_user_execution":
        ("proven", "Object ownership not enforced: an identity executed a "
         "workflow object MINTED BY A DIFFERENT identity (state-oracle proof "
         "with the owner's canary visible in the executing identity's result) "
         "— cross-user action forgery inside the business process."),
    "business_logic_cross_object_execution":
        ("proven", "Object boundary not enforced: a workflow step EXECUTED an "
         "object produced by a different flow/context (state-oracle proof) — "
         "type/context confusion lets one process consume another's objects."),
    "business_logic_cross_state_execution":
        ("proven", "State machine not enforced: a workflow object in a "
         "CANCELLED/REJECTED state was EXECUTED anyway (state-oracle proof) — "
         "rollback/cancel paths do not protect the object from execution."),
    "credential_exposure":
        ("proven", "Secret credential material is exposed in a response and "
         "the exposure reproduced on a fresh fetch — direct account/infrastructure "
         "compromise potential (values masked in all reports by design)."),
    "cors_misconfig":
        ("proven", "Arbitrary origins are reflected with credentials allowed "
         "(fresh-origin replay) — any website can read authenticated "
         "cross-origin responses in the victim's browser."),
    "open_redirect":
        ("proven", "Unvalidated redirect to an attacker-controlled "
         "destination (fresh target replay) — phishing/trust laundering."),
    "http_response_header_injection":
        ("proven", "Attacker input reaches a response header (CRLF shape) — "
         "header injection into proxies/browsers."),
    "missing_security_headers":
        ("indicated", "Protective headers absent — defense-in-depth gap "
         "(no browser-enforced XSS/clickjacking/framing protections)."),
    "server_banner_disclosure":
        ("indicated", "Server software version disclosed — reconnaissance aid."),
    "tech_banner_disclosure":
        ("indicated", "Technology stack disclosed — reconnaissance aid."),
    "vulnerable_js_dependency":
        ("indicated", "End-of-life client-side dependency served — known "
         "advisory class applies to every client."),
    "header_injection":
        ("proven", "Attacker input reaches response headers — injection into "
         "intermediaries and browsers."),
}

DEFAULT_PROFILE = ("indicated",
                   "Defect confirmed by verification; direct impact "
                   "demonstration not implemented for this class.")


def assess(finding) -> dict:
    """Impact proof for one finding (deterministic, additive to reports)."""
    grade, statement = IMPACT_PROFILES.get(finding.type, DEFAULT_PROFILE)
    ev_kinds = sorted({e.kind for e in finding.evidence})
    oob = any("oob" in k or "callback" in k for k in ev_kinds)
    verified = bool(finding.verification and finding.verification.passed)
    return {
        "grade": grade,
        "statement": statement,
        "safe_proof": ("non-destructive verification: fresh-input replay / "
                       "differential oracle / marker read — no data extraction, "
                       "no state change, no destructive payload"),
        "evidence_chain": {
            "request": finding.method + " " + finding.endpoint_url.split("?")[0],
            "parameter": finding.parameter,
            "evidence_kinds": ev_kinds,
            "out_of_band": oob,
            "verification": (finding.verification.method if finding.verification else ""),
            "verification_passed": verified,
            **({"authz_context": finding.authz_context} if getattr(finding, "authz_context", "") else {}),
        },
    }


# ============================================================================
# Phase 63 (v4.0.0) — Proof Engine / Evidence OS
# ============================================================================
# A finding is no longer a one-line "SQL Injection — High". Every verified
# finding becomes a SELF-CONTAINED PROOF FILE: the attack hypothesis that
# motivated the test, the preconditions, the exact requests/responses (bounded
# snippets), the identity and workflow state before/after, the demonstrated
# impact, and a step-by-step REPRODUCTION recipe an engineer can follow (or a
# CI job can re-run) to see the same proof again. This is the artifact that
# makes "Reproduce Finding" a button instead of an archaeology project.

HYPOTHESIS_BY_CLASS: dict[str, str] = {
    "sql_injection": "attacker-controlled input changes the boolean value of a "
                     "server-side query condition (observable differential)",
    "xss_reflected": "attacker-supplied markup survives into the response in an "
                     "executable context",
    "xss_dom": "attacker-controlled data reaches a DOM sink and executes in a "
               "real browser",
    "path_traversal": "a path parameter escapes the document root and reads a "
                      "marker file",
    "xxe": "an XML parser resolves external entities (file read / OOB fetch)",
    "ssrf": "the server fetches an attacker-chosen URL (OOB callback proves it)",
    "command_injection": "OS command execution observable via a non-destructive "
                         "OOB callback",
    "ssti": "a template engine evaluates a fresh arithmetic expression",
    "nosql_injection": "an injected query-operator object flips an auth decision",
    "csrf": "a hostile-origin state-changing request is accepted like a "
            "same-origin one",
    "jwt_security": "unsigned/alg-none tokens are accepted",
    "host_header_injection": "an attacker-controlled Host is reflected into "
                             "application output",
    "idor_bola": "a low-privilege session retrieves another identity's private "
                 "object (victim marker oracle)",
    "vertical_privilege_escalation": "a low-privilege session receives the "
                                     "privileged view of a protected surface",
    "business_logic_step_bypass": "a later workflow step creates its object "
                                  "without the mandatory predecessor",
    "business_logic_out_of_order": "the final workflow step executes a resource "
                                   "that was never created",
    "business_logic_value_tamper": "an approved value is replaced at execution "
                                   "time",
    "business_logic_duplicate_execution": "replaying the final step executes the "
                                          "same resource twice",
    "business_logic_privilege_escalation": "a UI-declared privileged option is "
                                           "executable by a lower role",
    "business_logic_cross_user_execution": "identity B (another session) executes "
                                           "a workflow object minted by identity A",
    "business_logic_cross_object_execution": "a workflow step executes an object "
                                             "produced by a different flow/context",
    "business_logic_cross_state_execution": "a workflow step executes an object "
                                            "in a cancelled/rejected state",
    "credential_exposure": "secret credential material is exposed in a response",
    "cors_misconfig": "arbitrary origins are reflected with credentials allowed",
    "open_redirect": "an unvalidated redirect to an attacker-controlled "
                     "destination",
    "http_response_header_injection": "attacker input reaches a response header",
    "missing_security_headers": "protective headers are absent",
    "server_banner_disclosure": "server software version disclosed",
    "tech_banner_disclosure": "technology stack disclosed",
    "vulnerable_js_dependency": "end-of-life client-side dependency served",
    "header_injection": "attacker input reaches response headers",
}
DEFAULT_HYPOTHESIS = "a defect class verified by the engine's oracle"


def _snippet(text: str, limit: int = 400) -> str:
    """A bounded, report-safe snippet (never a data dump)."""
    t = (text or "").strip()
    return t if len(t) <= limit else t[: limit - 3] + "..."


def build_proof(finding, state_before: str = "", state_after: str = "",
                reproduction: list | None = None) -> dict:
    """The Evidence-OS proof file for ONE verified finding.

    state_before/state_after: the workflow-oracle snapshot pair (workflow and
    authz classes); empty for request-level classes whose proof IS the
    differential. reproduction: ordered, human-executable steps (each a dict
    {step, request, expect}) — when omitted, a canonical recipe is derived
    from the evidence chain.
    """
    impact = assess(finding)
    verified = bool(finding.verification and finding.verification.passed)
    evidences = [{"kind": e.kind, "detail": _snippet(e.detail, 300),
                  "request_id": e.request_id} for e in finding.evidence]
    if reproduction is None:
        reproduction = _canonical_reproduction(finding)
    return {
        "finding_id": finding.id,
        "type": finding.type,
        "severity": finding.severity.value,
        "attack_hypothesis": HYPOTHESIS_BY_CLASS.get(finding.type, DEFAULT_HYPOTHESIS),
        "preconditions": _preconditions(finding),
        "requests": [{"method": finding.method,
                      "url": finding.endpoint_url.split("?")[0],
                      "parameter": finding.parameter}],
        "responses": evidences,
        "identity": getattr(finding, "authz_context", "") or "primary scan session",
        "state_before": _snippet(state_before),
        "state_after": _snippet(state_after),
        "impact": impact,
        "reproduction": reproduction,
        "confidence": round(finding.confidence, 3),
        "verification": ({"method": finding.verification.method,
                          "passed": verified,
                          "rounds": finding.verification.rounds,
                          "notes": _snippet(finding.verification.notes, 300)}
                         if finding.verification else None),
        "proof_grade": impact["grade"],
    }


def _preconditions(finding) -> list[str]:
    """What had to be true for this test to even run (honest, class-aware)."""
    pre = ["target reachable within scope"]
    if getattr(finding, "authz_context", ""):
        pre.append("two configured identities with different privileges "
                   "(authz accounts)")
    if finding.type.startswith("business_logic_"):
        pre.append("a learned multi-step flow with resource linkage and a "
                   "state oracle (workflow engine, learn phase)")
        pre.append("explicit operator permission (--logic-active)")
    if finding.type in ("xxe", "ssrf", "command_injection"):
        pre.append("an armed out-of-band (OAST) channel")
    if finding.type in ("xss_dom",):
        pre.append("a real browser engine (playwright) in the loop")
    if finding.type == "idor_bola":
        pre.append("a victim account with a unique marker value")
    return pre


def _canonical_reproduction(finding) -> list[dict]:
    """The default step-by-step recipe: repeat the proving request and expect
    the same oracle outcome. Deterministic, payload-free phrasing (reports
    stay safe to share)."""
    url = finding.endpoint_url.split("?")[0]
    steps = [{
        "step": 1,
        "request": f"authenticate a session with the application (as configured "
                   f"for the scan)",
        "expect": "an authenticated session cookie/header",
    }, {
        "step": 2,
        "request": f"send {finding.method} {url}"
                   + (f" with the tested parameter '{finding.parameter}' and the "
                      "canary value from the evidence chain" if finding.parameter
                      else " as recorded"),
        "expect": "the same evidence kind fires as in the attached proof "
                  f"({', '.join(sorted({e.kind for e in finding.evidence})[:3])})",
    }]
    if finding.type.startswith("business_logic_"):
        steps.insert(1, {
            "step": 2,
            "request": "walk the learned flow up to the step named in the proof, "
                       "on a FRESH session",
            "expect": "the resource id and state oracle observed in the proof",
        })
        steps[-1]["step"] = 3
    return steps


def reproduce_command(proof: dict) -> str:
    """A one-line, copy-pasteable reproduction cue for terminals and CI logs
    (the full recipe rides the proof file; this is the headline)."""
    req = (proof.get("requests") or [{}])[0]
    return (f"sentinel reproduce --finding {proof.get('finding_id', '')} "
            f"({req.get('method', 'GET')} {req.get('url', '')} "
            f"param={req.get('parameter', '') or '-'})")
