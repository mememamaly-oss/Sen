# SENTINEL 2.2.0 — Complete Bundle

Deterministic self-healing DAST platform + full real-test campaign artifacts.
Phase 50 (v2.2.0): Browser/DOM engine — Playwright/Chromium rendering, DOM XSS
execution proofs, div-form + JSON-body discovery, session cookie jar, CSRF-token
preservation. Real-target proof: ginandjuice.shop /blog?search DOM XSS verified
via WAF-bypassing attribute-injection vector.

## Contents
- source/            Full platform source (14 modules incl. browser.py, fixtures v4,
                     41-case test suite, ground truth 17TP/12TN)
- results/scans/     All real-target scans (testasp, testaspnet, testfire/Altoro,
                     ginandjuice/PortSwigger incl. v2.2.0 browser-phase production runs)
- results/benchmarks/ Benchmark evolution v1 -> v2.2.0 (F1 0.833 -> 1.000) + repair + repro
- results/reports/   HTML + PDF reports
- database/          sentinel.db (SQLite runs+findings store) + strategy_store.json
- docs/              WORKLOG.md + CHANGELOG.md

## Quick start
    cd source
    python3 sentinel/cli.py doctor            # 10/10 (browser_engine included)
    python3 sentinel/cli.py benchmark         # F1=1.000 (TP=17 FP=0 FN=0 TN=12)
    python3 sentinel/cli.py scan <authorized-target> --max-pages 25 --out results/scan.json
    python3 sentinel/cli.py serve             # REST + dashboard at 127.0.0.1:8022

Requires: Python 3.10+ stdlib; optional Playwright+Chromium for the DOM phase
(graceful degradation without it). Only scan targets you are authorized to test.
