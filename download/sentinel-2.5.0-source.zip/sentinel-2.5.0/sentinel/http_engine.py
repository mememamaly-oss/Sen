"""Phase 2: Request/Response Engine + Phase 3: Scope enforcement.
Scanners never build HTTP requests directly — they emit RequestMutations.
"""
from __future__ import annotations
import http.client, socket, ssl, time, urllib.parse, uuid
from dataclasses import dataclass, field
from .core import Endpoint, EventBus, ParamLocation, ScopeRule, VERSION, is_private_ip

DEFAULT_TIMEOUT = 12.0
# Engine fingerprint — OAST-channel detectors use it to reject SELF-callbacks
# (ENG-08): the engine follows same-host redirects, so an open-redirect target can
# bounce our probe URL back at the listener and WE fetch it. That callback carries
# this exact UA and must never count as target-side evidence.
USER_AGENT = f"Mozilla/5.0 (compatible; Sentinel/{VERSION}; +security-scanner)"


# ---------------------------------------------------------------- Mutations
@dataclass
class RequestMutation:
    """A single, replayable modification of an endpoint's request."""
    endpoint: Endpoint
    param_name: str = ""
    param_location: ParamLocation = ParamLocation.QUERY
    param_value: str = ""
    method: str = ""
    body_override: str = ""
    extra_headers: dict = field(default_factory=dict)
    note: str = ""


@dataclass
class Response:
    status: int = 0
    headers: dict = field(default_factory=dict)
    body: str = ""
    elapsed: float = 0.0
    url: str = ""
    error: str = ""
    request_id: str = ""
    redirect_chain: list = field(default_factory=list)   # ENG-01: [(status, absolute_url)] per followed hop

    @property
    def ok(self): return 200 <= self.status < 300

    def hop_location(self) -> str:
        """ENG-01: first-hop redirect target, whether the engine followed it or not.
        The engine auto-follows same-host redirects and returns the FINAL response —
        the original Location (e.g. a login-bypass oracle 302) used to be destroyed.
        This restores it deterministically without changing follow behavior."""
        if self.redirect_chain:
            return self.redirect_chain[0][1]
        return (self.headers or {}).get("location") or (self.headers or {}).get("Location") or ""


class RequestEngine:
    """Owns transport, timeouts, redirects, scope re-check after every hop.
    ENG-05: session cookie jar — Set-Cookie harvested from responses is replayed
    on subsequent same-host requests, mirroring a real browser session. This is
    the substrate that makes CSRF-protected flows and (Phase 51) authenticated
    scanning reachable; without it the server rejects every request that needs
    a session before the vulnerable code path is ever exercised."""
    def __init__(self, scope: ScopeRule, bus: EventBus, timeout: float = DEFAULT_TIMEOUT,
                 adaptive_timeout: float | None = None):
        self.scope, self.bus, self.timeout = scope, bus, adaptive_timeout or timeout
        self.base_timeout = timeout
        self.requests_sent = 0
        self.cookie_jar: dict[str, dict[str, str]] = {}   # host -> {name: value}
        self._ctx = ssl.create_default_context()
        self._ctx.check_hostname = False
        self._ctx.verify_mode = ssl.CERT_NONE

    # ---- build concrete URL/body from mutation
    def _render(self, m: RequestMutation) -> tuple[str, str, dict, str]:
        ep = m.endpoint
        q = [(p.name, p.value) for p in ep.parameters if p.location == ParamLocation.QUERY]
        body = m.body_override
        # ENG-06 (live-caught on demo.testfire.net/doLogin): a request with NO mutation
        # target (param_name empty — baseline fetches, and Phase 51 login requests) used
        # to go out with an EMPTY body even when the endpoint carried BODY/JSON params,
        # so credential POSTs transmitted nothing and the app rejected every one. The
        # engine must serialize the endpoint's own body fields in the request shape the
        # endpoint declares, exactly like a browser submitting that form.
        if not m.param_name and not m.body_override and (m.method or ep.method) in ("POST", "PUT", "PATCH"):
            bfields = [p for p in ep.parameters
                       if p.location in (ParamLocation.BODY, ParamLocation.JSON)]
            if bfields:
                if all(p.location == ParamLocation.JSON for p in bfields):
                    import json as _json
                    body = _json.dumps({p.name: (p.value or "") for p in bfields})
                else:
                    body = urllib.parse.urlencode([(p.name, p.value or "") for p in bfields])
        if m.param_name:
            # ENG-02: inherit the param's ACTUAL location from the endpoint definition.
            # Old code trusted m.param_location (default QUERY), so probes aimed at POST
            # body params were sent as URL query with an EMPTY body — the payload never
            # reached the app (live-caught: doLogin auth-bypass oracle invisible).
            eff_loc = m.param_location
            for p in ep.parameters:
                if p.name == m.param_name:
                    eff_loc = p.location
                    break
            hit = False
            q = []
            for p in ep.parameters:
                if p.location == ParamLocation.QUERY:
                    if p.name == m.param_name and eff_loc == ParamLocation.QUERY:
                        q.append((p.name, m.param_value)); hit = True
                    else:
                        q.append((p.name, p.value))
            if not hit and eff_loc == ParamLocation.QUERY:
                q.append((m.param_name, m.param_value))
            if eff_loc == ParamLocation.BODY and not m.body_override:
                # DISC-04 (live-caught on demo.testfire.net/doLogin): sibling body fields
                # with EMPTY default values made apps reject early (Altoro requires a
                # non-empty password before the SQL path is even reached) — the oracle
                # never fired. Deterministic fill: empty sibling body fields get a
                # benign constant so the app processes the request normally.
                fields = [(p.name, p.value or "sentinel") for p in ep.parameters
                          if p.location == ParamLocation.BODY]
                if not any(f[0] == m.param_name for f in fields):
                    fields.append((m.param_name, m.param_value))
                fields = [(m.param_name, m.param_value) if f[0] == m.param_name else f for f in fields]
                body = urllib.parse.urlencode(fields)
            # ENG-04 (live-proven on ginandjuice.shop /catalog/subscribe): JS-built
            # forms POST JSON (JSON.stringify + Content-Type application/json) — a
            # body-param endpoint silently sent x-www-form-urlencoded is rejected
            # by every JSON API, hiding the whole surface. Params with JSON location
            # render as a JSON object; siblings (e.g. harvested CSRF tokens) ride along.
            elif eff_loc == ParamLocation.JSON and not m.body_override:
                obj = {p.name: (p.value if p.value else "") for p in ep.parameters
                       if p.location == ParamLocation.JSON}
                obj[m.param_name] = m.param_value
                import json as _json
                body = _json.dumps(obj)
        parsed = urllib.parse.urlsplit(ep.url)
        base = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path, "", ""))
        url = base + ("?" + urllib.parse.urlencode(q) if q else "")
        if m.param_location == ParamLocation.PATH and m.param_name:
            url = url.replace("{" + m.param_name + "}", urllib.parse.quote(m.param_value, safe=""))
        headers = {"User-Agent": USER_AGENT}
        # ENG-03 (live-caught on demo.testfire.net/doLogin): http.client does NOT add
        # Content-Type for bodies — Tomcat then never parses the POST body, silently
        # hiding the entire POST attack surface. Required per HTML form spec.
        # ENG-04: JSON-location bodies get application/json (the request shape the
        # target's own JavaScript would have produced).
        if body and (m.method or ep.method) in ("POST", "PUT", "PATCH"):
            if not m.body_override and any(p.location == ParamLocation.JSON for p in ep.parameters):
                headers.setdefault("Content-Type", "application/json")
            else:
                headers.setdefault("Content-Type", "application/x-www-form-urlencoded")
        headers.update(ep.headers); headers.update(m.extra_headers)
        return url, m.method or ep.method, headers, body

    # ---- scope gate (checked BEFORE request and AFTER every redirect)
    def _scope_ok(self, url: str) -> tuple[bool, str]:
        p = urllib.parse.urlsplit(url)
        if p.scheme not in self.scope.allowed_schemes:
            return False, f"scheme {p.scheme} not allowed"
        host = p.hostname or ""
        if self.scope.allowed_hosts and host not in self.scope.allowed_hosts:
            if not any(host.endswith("." + d) or host == d for d in self.scope.allowed_domains):
                return False, f"host {host} outside allowed set"
        if self.scope.allowed_ports and p.port and p.port not in self.scope.allowed_ports:
            return False, f"port {p.port} not allowed"
        for dp in self.scope.denied_paths:
            if p.path.startswith(dp):
                return False, f"path matches denied prefix {dp}"
        if not self.scope.allow_private and is_private_ip(host):
            return False, f"private/localhost host {host} blocked by scope policy"
        return True, ""

    def _harvest_cookies(self, getheaders, host: str):
        """ENG-05: collect every Set-Cookie (http.client yields them as separate
        header tuples — a dict comprehension silently keeps only the LAST one)."""
        for k, v in getheaders():
            if k.lower() != "set-cookie":
                continue
            first = v.split(";", 1)[0]
            if "=" in first:
                n, _, val = first.partition("=")
                self.cookie_jar.setdefault(host, {})[n.strip()] = val.strip()

    def _cookie_header(self, host: str) -> str:
        ck = self.cookie_jar.get(host)
        if not ck:
            return ""
        return "; ".join(f"{k}={v}" for k, v in sorted(ck.items()))

    def send(self, m: RequestMutation) -> Response:
        url, method, headers, body = self._render(m)
        ok, why = self._scope_ok(url)
        if not ok:
            self.bus.emit("RequestBlockedByScope", url=url, reason=why)
            return Response(status=0, url=url, error="scope:" + why)
        rid = "req-" + uuid.uuid4().hex[:8]
        t0 = time.time()
        self.requests_sent += 1
        try:
            parsed = urllib.parse.urlsplit(url)
            # ENG-05: replay session cookies for this host (browser-equivalent session)
            ck = self._cookie_header(parsed.hostname or "")
            if ck:
                headers.setdefault("Cookie", ck)
            if parsed.scheme == "https":
                conn = http.client.HTTPSConnection(parsed.hostname, parsed.port, timeout=self.timeout, context=self._ctx)
            else:
                conn = http.client.HTTPConnection(parsed.hostname, parsed.port, timeout=self.timeout)
            path = parsed.path + ("?" + parsed.query if parsed.query else "")
            conn.request(method, path, body=body if method in ("POST", "PUT", "PATCH") else None, headers=headers)
            r = conn.getresponse()
            raw = r.read(2_000_000)
            self._harvest_cookies(r.getheaders, parsed.hostname or "")
            hdrs = {k.lower(): v for k, v in r.getheaders()}
            # ---- redirect handling with scope re-check (Phase 3 requirement)
            hops = 0
            chain = []                                        # ENG-01: preserve oracle info
            while r.status in (301, 302, 303, 307, 308) and "location" in hdrs and hops < self.scope.max_redirects:
                nxt = urllib.parse.urljoin(url, hdrs["location"])
                chain.append((r.status, nxt))
                ok2, why2 = self._scope_ok(nxt)
                if not ok2:
                    self.bus.emit("RedirectBlockedByScope", url=nxt, reason=why2)
                    break
                pu = urllib.parse.urlsplit(nxt)
                if pu.hostname != parsed.hostname and not self.scope.follow_cross_host:
                    break
                conn.close()
                if pu.scheme == "https":
                    conn = http.client.HTTPSConnection(pu.hostname, pu.port, timeout=self.timeout, context=self._ctx)
                else:
                    conn = http.client.HTTPConnection(pu.hostname, pu.port, timeout=self.timeout)
                # ENG-07 (live-caught via fixture v5 /doLogin): the hop request used to
                # reuse the ORIGINAL request's Cookie header, so cookies issued ON the
                # redirect response (login flows rotate the session: Set-Cookie SESS=s2
                # + AUTH=... on a 302) never reached the landing page — the hop arrived
                # anonymous and bounced straight back to the login gate. Rebuild the
                # Cookie header from the CURRENT jar for every hop, exactly like a
                # browser following a redirect chain.
                hop_headers = dict(headers)
                ck2 = self._cookie_header(pu.hostname or "")
                if ck2:
                    hop_headers["Cookie"] = ck2
                conn.request("GET", pu.path + ("?" + pu.query if pu.query else ""), headers=hop_headers)
                r = conn.getresponse(); raw = r.read(2_000_000)
                self._harvest_cookies(r.getheaders, pu.hostname or "")
                hdrs = {k.lower(): v for k, v in r.getheaders()}
                url = nxt; hops += 1
            conn.close()
            resp = Response(status=r.status, headers=hdrs, body=raw.decode("utf-8", "replace"),
                            elapsed=time.time() - t0, url=url, request_id=rid,
                            redirect_chain=chain)
            self.bus.emit("ResponseReceived", request_id=rid, url=url, status=r.status,
                          bytes=len(raw), ms=int(resp.elapsed * 1000))
            return resp
        except (socket.timeout, TimeoutError) as e:
            self.bus.emit("RequestTimeout", url=url, timeout=self.timeout)
            return Response(url=url, error=f"timeout:{type(e).__name__}", elapsed=time.time() - t0, request_id=rid)
        except Exception as e:
            self.bus.emit("RequestError", url=url, error=f"{type(e).__name__}: {e}"[:200])
            return Response(url=url, error=f"{type(e).__name__}: {e}"[:200], elapsed=time.time() - t0, request_id=rid)


def make_session_cookie_ep(ep: Endpoint, cookies: dict) -> Endpoint:
    """Phase 6: Session/Auth — clone endpoint with session cookies attached."""
    import copy
    c = copy.deepcopy(ep); c.cookies.update(cookies); c.auth_context = "session"
    return c
