"""Phase 9: Verification Engine + Phase 12: Finding Intelligence (dedup/correlation/risk)
+ Phase 19: Strategy Store (deterministic, verified-outcomes-only learning)
+ Phase 20: Failure Memory + Phase 18: Repair Gate infrastructure.
"""
from __future__ import annotations
import json, math, os, time, hashlib
from .core import Endpoint, EventBus, Finding, FindingStatus, Severity, Verification, ParamKind
from .http_engine import RequestEngine, RequestMutation
from .detect import SQLiDetector, XSSDetector, TraversalDetector, passive_audit, SECURITY_HEADERS


# ============================================================ VERIFICATION (Phase 9)
class VerificationEngine:
    """Candidate -> re-test with independent variant -> evidence -> confidence -> verdict.
    A candidate is NEVER a finding until this passes (spec: Candidate != Truth)."""

    def __init__(self, engine: RequestEngine, bus: EventBus):
        self.engine, self.bus = engine, bus

    def _replay(self, ep: Endpoint, param: str, value: str):
        return self.engine.send(RequestMutation(endpoint=ep, param_name=param, param_value=value))

    def verify(self, f: Finding, ep: Endpoint | None = None) -> Finding:
        self.bus.emit("VerificationStarted", finding=f.id, type=f.type)
        if f.type == "sql_injection":
            p = f.parameter
            base = "1"
            if ep and ep.param(p):
                base = ep.param(p).value if ep.param(p).value.isdigit() else "1"
            # PATH A — boolean oracle replay (blind)
            r1 = self._replay(ep, p, f"{base} AND 1=1")
            r2 = self._replay(ep, p, f"{base} AND 1=2")
            stable = (r1.ok and not r2.ok) or abs(len(r1.body or "") - len(r2.body or "")) > 200
            if stable:
                v = Verification(method="oracle:replay-2round", passed=True, confidence=0.95, rounds=2,
                                 notes=f"replay TRUE={r1.status} FALSE={r2.status}")
                f.verification, f.confidence = v, v.confidence
                f.status = FindingStatus.VERIFIED
            else:
                # PATH B — error-based replay: quote payload must reproduce DB error (independent variant: double-quote)
                from .detect import SQL_ERR_PATTERNS
                import re as _re
                alt_quot = base + '"' if "'" in str(f.evidence) else base + "'"
                r3 = self._replay(ep, p, base + '"')
                r4 = self._replay(ep, p, base + "'")
                err_repro = any((not r.ok and r.status >= 500) or any(pat.search(r.body or "") for pat in SQL_ERR_PATTERNS)
                                for r in (r3, r4) if r.status)
                v = Verification(method="error:replay-2variants", passed=err_repro,
                                 confidence=0.9 if err_repro else 0.15, rounds=2,
                                 notes=f"single+double quote variants reproduce DB error: {err_repro}")
                f.verification, f.confidence = v, v.confidence
                f.status = FindingStatus.VERIFIED if err_repro else FindingStatus.REJECTED

        elif f.type == "xss_reflected":
            alt = "<img src=x onerror=sentinel42()>"
            r = self._replay(ep, f.parameter, alt)
            executed_ctx = alt in (r.body or "")
            v = Verification(method="re-test:variant-payload", passed=executed_ctx,
                             confidence=0.9 if executed_ctx else 0.25, rounds=1,
                             notes="second independent payload also reflected unescaped")
            f.verification, f.confidence = v, v.confidence
            f.status = FindingStatus.VERIFIED if executed_ctx else FindingStatus.REJECTED

        elif f.type == "path_traversal":
            ev = str(f.evidence)
            if "win.ini" in ev or "[fonts]" in ev:
                variants = ["../" * 4 + "windows/win.ini", "../" * 6 + "windows/win.ini", "../" * 8 + "windows/win.ini"]
                markers = ("[fonts]",)
            elif "passwd" in ev or "root:x" in ev:
                variants = ["../" * 6 + "etc/passwd", "../" * 8 + "etc/passwd"]
                markers = ("root:x:0:0:",)
            else:
                variants = ["../" * 4 + "secret.txt", "../" * 6 + "secret.txt"]
                markers = ("SENTINEL-SECRET-FILE",)
            hit = False
            used = ""
            for alt in variants:
                r = self._replay(ep, f.parameter, alt)
                if any(m in (r.body or "") for m in markers):
                    hit, used = True, alt
                    break
            v = Verification(method="re-test:same-marker-alt-depth", passed=hit,
                             confidence=0.9 if hit else 0.15, rounds=len(variants),
                             notes=f"alternative depth payload {used[:40]!r} reproduces leak: {hit}")
            f.verification, f.confidence = v, v.confidence
            f.status = FindingStatus.VERIFIED if hit else FindingStatus.REJECTED

        elif f.type == "open_redirect":
            r = self._replay(ep, f.parameter, "https://sentinel-redirect-check.example.org/second")
            ok = "sentinel-redirect-check.example.org" in (r.headers.get("location", "") or r.body or "")
            v = Verification(method="re-test:second-host", passed=ok, confidence=0.85 if ok else 0.2, rounds=1)
            f.verification, f.confidence = v, v.confidence
            f.status = FindingStatus.VERIFIED if ok else FindingStatus.REJECTED

        else:  # passive findings: single-response evidence, verified by definition of presence
            v = Verification(method="single-response-evidence", passed=True, confidence=0.98, rounds=1)
            f.verification, f.confidence = v, v.confidence
            f.status = FindingStatus.VERIFIED

        self.bus.emit("VerificationCompleted", finding=f.id, type=f.type,
                      passed=f.verification.passed if f.verification else False,
                      status=f.status.value, confidence=f.confidence)
        return f


# ============================================================ FINDING PIPELINE (Phase 12)
RISK_WEIGHTS = {"sql_injection": 9, "xss_reflected": 7, "path_traversal": 7, "open_redirect": 4,
                "missing_security_headers": 2, "server_banner_disclosure": 1, "tech_banner_disclosure": 1}

class FindingPipeline:
    def __init__(self, bus: EventBus):
        self.bus = bus

    def dedup(self, findings: list[Finding]) -> list[Finding]:
        seen: dict[str, Finding] = {}
        for f in findings:
            fp = f.fingerprint()
            if fp in seen:
                seen[fp].evidence.extend(f.evidence)
                self.bus.emit("FindingDeduplicated", fingerprint=fp, kept=seen[fp].id, dropped=f.id)
            else:
                seen[fp] = f
        return list(seen.values())

    def correlate(self, findings: list[Finding]) -> list[Finding]:
        """Merge duplicate evidence for the SAME injection point (type + full path + param).
        Different endpoints/parameters stay distinct findings — they are distinct root causes."""
        roots: dict[str, Finding] = {}
        for f in sorted(findings, key=lambda x: -RISK_WEIGHTS.get(x.type, 1)):
            key = f"{f.type}|{f.endpoint_url.split('?')[0]}|{f.parameter}"
            if key in roots:
                roots[key].evidence.extend(f.evidence[:2])
            else:
                roots[key] = f
        return list(roots.values())

    def risk(self, f: Finding) -> int:
        """technical severity x confidence x exposure, 0-100."""
        base = RISK_WEIGHTS.get(f.type, 3) * 10
        conf = f.confidence or 0.5
        auth_factor = 1.0
        return min(100, int(base * conf * auth_factor))


# ============================================================ STRATEGY STORE (Phase 19/25/26)
def wilson_lower(successes: int, n: int, z: float = 1.96) -> float:
    """Wilson score lower bound — sample-size-aware (spec 26)."""
    if n == 0: return 0.0
    p = successes / n
    denom = 1 + z * z / n
    centre = p + z * z / (2 * n)
    margin = z * math.sqrt((p * (1 - p) + z * z / (4 * n)) / n)
    return max(0.0, (centre - margin) / denom)


class StrategyStore:
    """Learning = deterministic statistics from VERIFIED outcomes only (spec 51)."""
    def __init__(self, path: str | None = None):
        self.path = path
        self.stats: dict[str, dict] = {}
        if path and os.path.exists(path):
            self.stats = json.load(open(path))

    def key(self, scanner: str, strategy: str, context: str = "default") -> str:
        return f"{scanner}:{context}:{strategy}"

    def record(self, scanner: str, strategy: str, verified: bool, context: str = "default"):
        k = self.key(scanner, strategy, context)
        s = self.stats.setdefault(k, {"n": 0, "verified": 0, "failed": 0})
        s["n"] += 1
        s["verified" if verified else "failed"] += 1
        self.flush()

    def order(self, scanner: str, strategies: list[str], context: str = "default") -> list[str]:
        """Deterministic ordering by Wilson lower bound; ties broken alphabetically."""
        def lb(st):
            s = self.stats.get(self.key(scanner, st, context), {"n": 0, "verified": 0})
            return (wilson_lower(s["verified"], s["n"]), s["n"])
        return sorted(strategies, key=lambda st: (-lb(st)[0], st))

    def flush(self):
        if self.path:
            json.dump(self.stats, open(self.path, "w"), indent=1)


# ============================================================ FAILURE MEMORY + REPAIR (Phase 18/22)
class FailureMemory:
    """Every failure becomes a permanent record (spec 27) + auto regression case (spec 28)."""
    def __init__(self, path: str | None = None):
        self.path, self.records = path, []
        if path and os.path.exists(path):
            self.records = json.load(open(path))

    def record(self, scanner: str, error: str, context: dict) -> str:
        fid = "fail-" + hashlib.sha1(f"{scanner}{error}{time.time()}".encode()).hexdigest()[:10]
        self.records.append({"id": fid, "scanner": scanner, "error": error[:300],
                             "context": context, "t": time.time()})
        self.flush()
        return fid

    def flush(self):
        if self.path:
            json.dump(self.records, open(self.path, "w"), indent=1)


class RepairClassifier:
    """Deterministic failure -> repair rule mapping (spec 22)."""
    RULES = {
        "timeout_spike": {
            "match": lambda err, ctx: "timeout" in err.lower(),
            "action": {"multiply_timeout": 3.0, "retry": 1},
            "validation": {"benchmark": "local-fixture-v1", "regression": "all"},
        },
        "connection_reset": {
            "match": lambda err, ctx: "ConnectionReset" in err or "RemoteDisconnected" in err,
            "action": {"retry": 2, "backoff_ms": 400},
            "validation": {"benchmark": "local-fixture-v1", "regression": "all"},
        },
        "dns_failure": {
            "match": lambda err, ctx: "gaierror" in err or "Name or service" in err,
            "action": {"skip_endpoint": True, "quarantine_scanner": False},
            "validation": {"regression": "all"},
        },
    }

    def classify(self, error: str, ctx: dict) -> tuple[str, dict] | None:
        for name, rule in self.RULES.items():
            try:
                if rule["match"](error, ctx):
                    return name, rule
            except Exception:
                continue
        return None


class RepairGate:
    """spec 23/38: repair candidates are applied in an isolated copy, tested, benchmarked,
    compared, then accepted or rolled back. Never direct self-modification."""
    def __init__(self, bench_fn, regression_fn):
        self.bench_fn, self.regression_fn = bench_fn, regression_fn

    def attempt(self, failure_id: str, rule_name: str, action: dict, apply_fn, label: str = "") -> dict:
        result = {"failure_id": failure_id, "rule": rule_name, "label": label,
                  "steps": [], "accepted": False}
        for step, fn, ok_check in [
            ("apply_in_isolation", apply_fn, lambda r: r is True),
            ("regression_suite", self.regression_fn, lambda r: r.get("passed") is True),
            ("benchmark_compare", self.bench_fn, lambda r: r.get("acceptable") is True),
        ]:
            try:
                r = fn()
                ok = ok_check(r)
            except Exception as e:
                r, ok = {"error": str(e)}, False
            result["steps"].append({"step": step, "ok": ok, "detail": r if isinstance(r, dict) else r})
            if not ok:
                result["accepted"] = False
                result["rollback_reason"] = f"gate failed at: {step}"
                return result
        result["accepted"] = True
        return result
