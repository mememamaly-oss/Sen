SENTINEL v2.8.0 — COMPLETE BUNDLE ("Intelligence Layer" Release)
===============================================================
sentinel-2.8.0-source.zip   self-sufficient source: 26-module engine incl.
                           the six intelligence engines (authz / secrets /
                           paramintel / coverage / appmap / fingerprint+impact),
                           fixture v8, 67-test suite, ground truth v8 (30 TP / 24 TN).
                           Self-check: doctor 13/13 + benchmark F1=1.000
                           deterministic (run-3c0652b6be, authz armed).
sentinel-results/           every real-target artifact of the campaign,
                           incl. the v2.8.0 testfire live scan (672 req, 74
                           verified, 0 rejected) and the LIVE multi-user
                           authorization battery (48 req): vertical_privilege_
                           escalation VERIFIED on /admin/admin.jsp via the
                           chained SQLi -> admin-session -> role-differential
                           path, VR-18 reproduced, impact PROVEN.
CHANGELOG.md / WORKLOG.md   release notes + the full build history.
